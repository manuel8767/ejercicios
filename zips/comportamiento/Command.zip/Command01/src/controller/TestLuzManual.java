package controller;

import model.Comando;
import model.ComandoEncenderLuz;
import model.Luz;
import view.LuzView;

public class TestLuzManual {
    public static void main(String[] args) {
        Luz luz = new Luz();
        Comando comando = new ComandoEncenderLuz(luz);
        ControlRemoto control = new ControlRemoto();
        LuzView vista = new LuzView();

        control.setComando(comando);
        control.presionarBoton();
        vista.mostrarEncendido();
    }
}