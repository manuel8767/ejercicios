package model;

public interface Comando {
    void ejecutar();
}