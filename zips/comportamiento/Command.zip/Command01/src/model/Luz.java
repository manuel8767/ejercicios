package model;

public class Luz {
    public void encender() {
        System.out.println("La luz está encendida.");
    }
}