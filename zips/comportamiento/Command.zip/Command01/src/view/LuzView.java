package view;


public class LuzView {
    public void mostrarEncendido() {
        System.out.println("Vista: La luz fue encendida correctamente.");
    }
}