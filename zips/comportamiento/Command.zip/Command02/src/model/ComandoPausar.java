package model;

public class ComandoPausar implements Comando {
    private Reproductor reproductor;

    public ComandoPausar(Reproductor r) {
        this.reproductor = r;
    }

    public void ejecutar() {
        reproductor.pausar();
    }
}