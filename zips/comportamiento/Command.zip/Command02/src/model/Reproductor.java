package model;

public class Reproductor {
    public void reproducir() {
        System.out.println("Reproduciendo música...");
    }

    public void pausar() {
        System.out.println("Música en pausa.");
    }
}