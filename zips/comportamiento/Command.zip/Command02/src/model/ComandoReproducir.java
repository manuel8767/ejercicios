package model;

public class ComandoReproducir implements Comando {
    private Reproductor reproductor;

    public ComandoReproducir(Reproductor r) {
        this.reproductor = r;
    }

    public void ejecutar() {
        reproductor.reproducir();
    }
}