package controller;

import model.Comando;

public class ControlMusical {
    public void ejecutarComando(Comando comando) {
        comando.ejecutar();
    }
}