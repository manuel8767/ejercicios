package controller;

import model.Comando;
import model.ComandoPausar;
import model.ComandoReproducir;
import model.Reproductor;
import view.ReproductorView;

public class TestReproductorManual {
    public static void main(String[] args) {
        Reproductor rep = new Reproductor();
        Comando cmdReproducir = new ComandoReproducir(rep);
        Comando cmdPausar = new ComandoPausar(rep);
        ControlMusical control = new ControlMusical();
        ReproductorView vista = new ReproductorView();

        control.ejecutarComando(cmdReproducir);
        vista.mostrarEstado("Reproduciendo");

        control.ejecutarComando(cmdPausar);
        vista.mostrarEstado("Pausado");
    }
}