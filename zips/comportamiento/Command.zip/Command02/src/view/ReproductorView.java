package view;

public class ReproductorView {
    public void mostrarEstado(String estado) {
        System.out.println("Estado actual: " + estado);
    }
}