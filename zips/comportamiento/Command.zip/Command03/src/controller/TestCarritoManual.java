package controller;

import model.Carrito;
import model.Comando;
import model.ComandoAgregarProducto;
import view.CarritoView;

public class TestCarritoManual {
    public static void main(String[] args) {
        Carrito carrito = new Carrito();
        ControlCarrito control = new ControlCarrito();
        CarritoView vista = new CarritoView();

        Comando cmd1 = new ComandoAgregarProducto(carrito, "Camisa");
        Comando cmd2 = new ComandoAgregarProducto(carrito, "Zapatos");

        control.ejecutar(cmd1);
        control.ejecutar(cmd2);

        vista.mostrarCarrito(carrito.getProductos());
    }
}