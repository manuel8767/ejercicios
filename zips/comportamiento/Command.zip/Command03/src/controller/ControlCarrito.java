package controller;

import model.Comando;

public class ControlCarrito {
    public void ejecutar(Comando comando) {
        comando.ejecutar();
    }
}