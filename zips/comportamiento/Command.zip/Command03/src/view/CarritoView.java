package view;

import java.util.List;

public class CarritoView {
    public void mostrarCarrito(List<String> productos) {
        System.out.println("Productos en el carrito:");
        for (String p : productos) {
            System.out.println(" - " + p);
        }
    }
}