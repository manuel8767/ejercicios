package model;

import java.util.ArrayList;

public class Carrito {
    private ArrayList<String> productos = new ArrayList<>();

    public void agregarProducto(String producto) {
        productos.add(producto);
        System.out.println("Producto agregado: " + producto);
    }

    public ArrayList<String> getProductos() {
        return productos;
    }
}