package model;

public class ComandoAgregarProducto implements Comando {
    private Carrito carrito;
    private String producto;

    public ComandoAgregarProducto(Carrito carrito, String producto) {
        this.carrito = carrito;
        this.producto = producto;
    }

    public void ejecutar() {
        carrito.agregarProducto(producto);
    }
}