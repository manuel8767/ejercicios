package model;

public class Supermarket {

    private String product;
    private String price;

    public Supermarket(String product, String price) {
        this.product = product;
        this.price = price;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public Backup createBackup() {
        return new Backup(this, product, price);
    }

    public static class Backup {

        private Supermarket supermarket;
        private String product2;
        private String price2;

        public Backup(Supermarket supermarket, String product2, String price2) {
            this.supermarket = supermarket;
            this.product2 = product2;
            this.price2 = price2;
        }

        public void restore() {
            supermarket.setProduct(product2);
            supermarket.setPrice(price2);
        }

    }

}
