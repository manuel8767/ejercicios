package controller;

import model.GestorBackup;
import model.Supermarket;
import view.VistaConsola;

public class Controller {

    public void run() {

        boolean salir = false;
        String product="", price="";
        Supermarket supermarket=new Supermarket(product, price);
        GestorBackup gestor=new GestorBackup();
        gestor.saveBackup(supermarket.createBackup());
        VistaConsola vista=new VistaConsola();

        while (!salir) {
            vista.mostrarInformacion("\n--- MENÚ ---");
            vista.mostrarInformacion("1. Modificar producto");
            vista.mostrarInformacion("2. Mostrar estado actual");
            vista.mostrarInformacion("3. Guardar backup");
            vista.mostrarInformacion("4. Restaurar última versión guardada");
            vista.mostrarInformacion("5. Salir");

            String opcion = vista.leerTexto("\nSelecciona una opción: ");

            switch (opcion) {
                case "1" -> {
                    product=vista.leerTexto("\nEscribe el nombre del producto: ");
                    price=vista.leerTexto("Escribe el precio del producto: ");
                    supermarket.setProduct(product);
                    supermarket.setPrice(price);
                    break;
                }
                case "2" -> {
                    vista.mostrarInformacion("\nVersión actual:\nProducto: "+supermarket.getProduct()+"\nPrecio: "+supermarket.getPrice());
                    break;
                }
                case "3" -> {
                    gestor.saveBackup(supermarket.createBackup());
                    vista.mostrarInformacion("\nBackup guardado exitosamente.");
                    break;
                }
                case "4" -> {
                    gestor.restoreBackup();
                    vista.mostrarInformacion("\nMensaje restaurado.");
                    break;
                }
                case "5" -> {
                    salir = true;
                }
            }
        }
    }
}
