package controller;

import model.GestorBackup;
import model.Text;
import view.VistaConsola;

public class Controller {

    public void run() {

        boolean salir = false;
        String message="";
        Text text=new Text(message);
        GestorBackup gestor=new GestorBackup();
        gestor.saveBackup(text.createBackup());
        VistaConsola vista=new VistaConsola();

        while (!salir) {
            vista.mostrarInformacion("\n--- MENÚ ---");
            vista.mostrarInformacion("1. Modificar texto");
            vista.mostrarInformacion("2. Mostrar estado actual");
            vista.mostrarInformacion("3. Guardar backup");
            vista.mostrarInformacion("4. Restaurar última versión guardada");
            vista.mostrarInformacion("5. Salir");

            String opcion = vista.leerTexto("\nSelecciona una opción: ");

            switch (opcion) {
                case "1" -> {
                    message=vista.leerTexto("\nEscribe tu mensaje: ");
                    text.setMessage(message);
                    break;
                }
                case "2" -> {
                    vista.mostrarInformacion("\nVersión actual:\nMensaje: "+text.getMessage());
                    break;
                }
                case "3" -> {
                    gestor.saveBackup(text.createBackup());
                    vista.mostrarInformacion("\nBackup guardado exitosamente.");
                    break;
                }
                case "4" -> {
                    gestor.restoreBackup();
                    vista.mostrarInformacion("\nMensaje restaurado.");
                    break;
                }
                case "5" -> {
                    salir = true;
                }
            }
        }
    }
}
