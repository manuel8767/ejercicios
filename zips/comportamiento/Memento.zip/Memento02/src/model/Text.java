package model;

public class Text {

    private String message;;

    public Text(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Backup createBackup() {
        return new Backup(this, message);
    }

    public static class Backup {

        private Text text;
        private String message2;

        public Backup(Text text, String message2) {
            this.message2 = message2;
        }

        public void restore() {
            text.setMessage(message2);
        }

    }

}
