package model;

public class GestorBackup {

	private Text.Backup backup;

	public void saveBackup(Text.Backup backup) {
		this.backup = backup;
	}

	public String restoreBackup() {
		if (backup != null) {
			backup.restore();
		}
		return "\nNo hay backups disponibles.";
	}

}
