package controller;

import model.Character;
import model.GestorBackup;
import view.VistaConsola;

public class Controller {

    public void run() {

        boolean salir = false;
        String name="Charizard", level="Max", skill="Wing Attack";
        Character character= new Character(name, level, skill);
        GestorBackup gestor=new GestorBackup();
        gestor.saveBackup(character.createBackup());
        VistaConsola vista=new VistaConsola();

        while (!salir) {
            vista.mostrarInformacion("\n--- MENÚ ---");
            vista.mostrarInformacion("1. Crear nueva versión del personaje");
            vista.mostrarInformacion("2. Mostrar estado actual");
            vista.mostrarInformacion("3. Guardar backup");
            vista.mostrarInformacion("4. Restaurar última versión guardada");
            vista.mostrarInformacion("5. Salir");

            String opcion = vista.leerTexto("\nSelecciona una opción: ");

            switch (opcion) {
                case "1" -> {
                    name=vista.leerTexto("\nIngresa el nombre: ");
                    level=vista.leerTexto("Ingresa el nivel: ");
                    skill=vista.leerTexto("Ingresa la habilidad: ");
                    character.setName(name);
                    character.setLevel(level);
                    character.setSkill(skill);
                    break;
                }
                case "2" -> {
                    vista.mostrarInformacion("\nVersión actual:\nNombre: "+character.getName()+"\nNivel: "+character.getLevel()+"\nHabilidad: "+character.getSkill());
                    break;
                }
                case "3" -> {
                    gestor.saveBackup(character.createBackup());
                    vista.mostrarInformacion("\nBackup guardado exitosamente.");
                    break;
                }
                case "4" -> {
                    gestor.restoreBackup();
                    vista.mostrarInformacion("\nPersonaje restaurado.");
                    break;
                }
                case "5" -> {
                    salir = true;
                }
            }
        }
    }
}
