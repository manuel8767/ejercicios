package model;

public class Character {

    private String name, level, skill;

    public Character(String name, String level, String skill) {
        this.name = name;
        this.level = level;
        this.skill = skill;
    }

        public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getSkill() {
        return skill;
    }

    public void setSkill(String skill) {
        this.skill = skill;
    }

    public Backup createBackup() {
        return new Backup(this, name, level, skill);
    }

    public static class Backup {

        private Character chracter;
        private String name2, level2, skill2;

        public Backup(Character chracter, String name2, String level2, String skill2) {
            this.chracter = chracter;
            this.name2 = name2;
            this.level2 = level2;
            this.skill2 = skill2;
        }

        public void restore() {
            chracter.setName(name2);
            chracter.setLevel(level2);
            chracter.setSkill(skill2);
        }

    }

}
