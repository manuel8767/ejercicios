package model;

public class GestorBackup {

	private Character.Backup backup;

	public void saveBackup(Character.Backup backup) {
		this.backup = backup;
	}

	public String restoreBackup() {
		if (backup != null) {
			backup.restore();
		}
		return "\nNo hay backups disponibles.";
	}

}
