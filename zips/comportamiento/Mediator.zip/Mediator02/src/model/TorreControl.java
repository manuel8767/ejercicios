package model;

import java.util.ArrayList;
import java.util.List;

public class TorreControl implements MediadorTrafico {
    private boolean pistaLibre = true;
    private List<Avion> enEspera = new ArrayList<>();

    public void solicitarPermiso(Avion avion) {
        if (pistaLibre) {
            pistaLibre = false;
            avion.despegar();
        } else {
            System.out.println("Pista ocupada. " + avion.getNombre() + " en espera.");
            enEspera.add(avion);
        }
    }

    public void notificarDespegue(Avion avion) {
        pistaLibre = true;
        if (!enEspera.isEmpty()) {
            Avion siguiente = enEspera.remove(0);
            solicitarPermiso(siguiente);
        }
    }
}