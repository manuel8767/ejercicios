package model;

public class Avion {
    private String nombre;
    private MediadorTrafico mediador;

    public Avion(String nombre, MediadorTrafico mediador) {
        this.nombre = nombre;
        this.mediador = mediador;
    }

    public void solicitarDespegue() {
        System.out.println(nombre + " solicita permiso de despegue");
        mediador.solicitarPermiso(this);
    }

    public void despegar() {
        System.out.println(nombre + " ha despegado");
        mediador.notificarDespegue(this);
    }

    public String getNombre() {
        return nombre;
    }
}