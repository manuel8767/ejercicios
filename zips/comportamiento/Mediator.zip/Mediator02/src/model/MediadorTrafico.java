package model;

public interface MediadorTrafico {
    void solicitarPermiso(Avion avion);
    void notificarDespegue(Avion avion);
}