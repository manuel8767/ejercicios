package controller;

import model.Avion;
import model.MediadorTrafico;
import model.TorreControl;
import view.TraficoView;

public class TestTraficoManual {
    public static void main(String[] args) {
        MediadorTrafico torre = new TorreControl();

        Avion a1 = new Avion("Avión A", torre);
        Avion a2 = new Avion("Avión B", torre);
        Avion a3 = new Avion("Avión C", torre);

        ControlTraficoController c1 = new ControlTraficoController(a1);
        ControlTraficoController c2 = new ControlTraficoController(a2);
        ControlTraficoController c3 = new ControlTraficoController(a3);

        TraficoView vista = new TraficoView();

        vista.mostrar("Inicio del tráfico aéreo:");
        c1.intentarDespegar();
        c2.intentarDespegar();
        c3.intentarDespegar();
    }
}