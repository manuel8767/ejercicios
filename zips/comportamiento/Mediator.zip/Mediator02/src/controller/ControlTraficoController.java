package controller;


import model.Avion;

public class ControlTraficoController {
    private Avion avion;

    public ControlTraficoController(Avion avion) {
        this.avion = avion;
    }

    public void intentarDespegar() {
        avion.solicitarDespegue();
    }
}