package view;

public class TraficoView {
    public void mostrar(String mensaje) {
        System.out.println("Vista: " + mensaje);
    }
}