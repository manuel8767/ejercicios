package model;

public interface MediadorFormulario {
    void cambiarEstado(String origen, boolean habilitado);
}