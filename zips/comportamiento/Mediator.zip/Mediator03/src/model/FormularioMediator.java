package model;

public class FormularioMediator implements MediadorFormulario {
    private BotonEnviar boton;

    public void registrarBoton(BotonEnviar b) {
        this.boton = b;
    }

    public void cambiarEstado(String origen, boolean habilitado) {
        if (origen.equals("AceptarCondiciones")) {
            boton.setHabilitado(habilitado);
        }
    }
}