package model;


public class CheckBoxCondicion extends CampoFormulario {
    public CheckBoxCondicion(String nombre, MediadorFormulario mediador) {
        super(nombre, mediador);
    }

    public void interactuar() {
        System.out.println("Se marcó la casilla: " + nombre);
        mediador.cambiarEstado(nombre, true);
    }
}