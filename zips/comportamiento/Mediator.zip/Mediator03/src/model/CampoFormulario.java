package model;

public abstract class CampoFormulario {
    protected MediadorFormulario mediador;
    protected String nombre;
    protected boolean habilitado;

    public CampoFormulario(String nombre, MediadorFormulario mediador) {
        this.nombre = nombre;
        this.mediador = mediador;
        this.habilitado = true;
    }

    public abstract void interactuar();

    public void setHabilitado(boolean h) {
        this.habilitado = h;
        System.out.println("Campo '" + nombre + "' ahora está " + (h ? "habilitado" : "deshabilitado"));
    }

    public boolean isHabilitado() {
        return habilitado;
    }

    public String getNombre() {
        return nombre;
    }
}