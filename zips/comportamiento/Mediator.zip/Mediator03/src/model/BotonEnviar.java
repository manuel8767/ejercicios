package model;

public class BotonEnviar extends CampoFormulario {
    public BotonEnviar(String nombre, MediadorFormulario mediador) {
        super(nombre, mediador);
        this.habilitado = false;
    }

    public void interactuar() {
        if (habilitado) {
            System.out.println("Formulario enviado");
        } else {
            System.out.println("Botón deshabilitado");
        }
    }
}