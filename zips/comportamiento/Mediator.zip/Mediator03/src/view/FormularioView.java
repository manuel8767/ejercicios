package view;

public class FormularioView {
    public void mostrar(String msg) {
        System.out.println("Vista: " + msg);
    }
}