package controller;

import model.CampoFormulario;

public class FormularioController {
    private CampoFormulario campo;

    public FormularioController(CampoFormulario campo) {
        this.campo = campo;
    }

    public void ejecutarAccion() {
        campo.interactuar();
    }
}