package controller;

import model.BotonEnviar;
import model.CheckBoxCondicion;
import model.FormularioMediator;
import view.FormularioView;

public class TestFormularioManual {
    public static void main(String[] args) {
        FormularioMediator mediador = new FormularioMediator();
        BotonEnviar boton = new BotonEnviar("Enviar", mediador);
        CheckBoxCondicion check = new CheckBoxCondicion("AceptarCondiciones", mediador);

        mediador.registrarBoton(boton);

        FormularioController cCheck = new FormularioController(check);
        FormularioController cBoton = new FormularioController(boton);
        FormularioView vista = new FormularioView();

        vista.mostrar("Antes de aceptar condiciones:");
        cBoton.ejecutarAccion();

        vista.mostrar("Aceptando condiciones:");
        cCheck.ejecutarAccion();

        vista.mostrar("Intentando enviar:");
        cBoton.ejecutarAccion();
    }
}