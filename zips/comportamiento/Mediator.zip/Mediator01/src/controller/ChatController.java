package controller;

import model.UsuarioChat;

public class ChatController {
    private UsuarioChat usuario;

    public ChatController(UsuarioChat usuario) {
        this.usuario = usuario;
    }

    public void enviarMensaje(String mensaje) {
        usuario.enviar(mensaje);
    }
}