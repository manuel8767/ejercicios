package controller;

import model.MediadorChatConcreto;
import model.UsuarioChat;
import model.UsuarioConcreto;
import view.ChatView;

public class TestChatManual {
    public static void main(String[] args) {
        MediadorChatConcreto mediador = new MediadorChatConcreto();

        UsuarioChat ana = new UsuarioConcreto(mediador, "Ana");
        UsuarioChat luis = new UsuarioConcreto(mediador, "Luis");
        UsuarioChat pedro = new UsuarioConcreto(mediador, "Pedro");

        mediador.agregarUsuario(ana);
        mediador.agregarUsuario(luis);
        mediador.agregarUsuario(pedro);

        ChatController controllerAna = new ChatController(ana);
        ChatView vista = new ChatView();

        vista.mostrar("Ana envía un mensaje:");
        controllerAna.enviarMensaje("¡Hola a todos!");
    }
}