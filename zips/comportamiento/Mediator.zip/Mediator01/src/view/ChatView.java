package view;

public class ChatView {
    public void mostrar(String mensaje) {
        System.out.println("Vista: " + mensaje);
    }
}