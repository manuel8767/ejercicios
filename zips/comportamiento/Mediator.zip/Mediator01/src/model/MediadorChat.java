package model;

public interface MediadorChat {
    void enviarMensaje(String mensaje, UsuarioChat usuario);
}