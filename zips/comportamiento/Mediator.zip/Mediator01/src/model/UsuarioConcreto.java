package model;

public class UsuarioConcreto extends UsuarioChat {
    public UsuarioConcreto(MediadorChat mediador, String nombre) {
        super(mediador, nombre);
    }

    public void enviar(String mensaje) {
        System.out.println(nombre + ": " + mensaje);
        mediador.enviarMensaje(mensaje, this);
    }

    public void recibir(String mensaje) {
        System.out.println(nombre + " recibió: " + mensaje);
    }
}