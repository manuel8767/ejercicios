package model;

import java.util.ArrayList;
import java.util.List;

public class MediadorChatConcreto implements MediadorChat {
    private List<UsuarioChat> usuarios = new ArrayList<>();

    public void agregarUsuario(UsuarioChat usuario) {
        usuarios.add(usuario);
    }

    public void enviarMensaje(String mensaje, UsuarioChat emisor) {
        for (UsuarioChat usuario : usuarios) {
            if (usuario != emisor) {
                usuario.recibir(mensaje);
            }
        }
    }
}