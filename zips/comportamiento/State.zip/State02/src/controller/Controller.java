package controller;

import model.TrafficLight;
import view.VistaConsola;

public class Controller {

    public void run() {

        byte option;
        TrafficLight trafficLight=new TrafficLight();
        VistaConsola vista=new VistaConsola();

        do { 

            option=Byte.parseByte(vista.leerTexto("\nDijita la opción que desees:\n1. Mostrar estado actual del semáforo\n2. Salir\n\n"));

            switch (option) {
                case 1 -> {
                    vista.mostrarInformacion(trafficLight.action());
                    break;
                }
                case 2 -> {
                    break;
                }
            }

        } while (option!=2);
        System.exit(0);

    }

}
