package model;

public abstract class State {

    public abstract String action(TrafficLight trafficLight);

}
