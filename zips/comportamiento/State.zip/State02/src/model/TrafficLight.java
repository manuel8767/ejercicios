package model;

public class TrafficLight {

    private State state;

    public TrafficLight() {
        this.setState(new Red());
    }

    public void setState(State state) {
        this.state = state;
    }

    public String action() {
        return state.action(this);
    }

}
