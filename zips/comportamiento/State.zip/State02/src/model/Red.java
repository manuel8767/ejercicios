package model;

public class Red extends State {

    @Override
    public String action(TrafficLight trafficLight) {
        trafficLight.setState(new Yellow());
        return "\nLuz Roja.";
    }

}
