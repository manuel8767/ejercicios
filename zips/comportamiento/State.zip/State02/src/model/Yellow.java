package model;

public class Yellow extends State {

    @Override
    public String action(TrafficLight trafficLight) {
        trafficLight.setState(new Green());
        return "\nLuz Amarilla.";
    }

}
