package model;

public class Green extends State {

    @Override
    public String action(TrafficLight trafficLight) {
        trafficLight.setState(new Red());
        return "\nLuz Verde.";
    }

}
