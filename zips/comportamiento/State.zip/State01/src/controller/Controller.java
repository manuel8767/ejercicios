package controller;

import model.Close;
import model.Game;
import model.Loading;
import view.VistaConsola;

public class Controller {

    public void run() {

        byte option;
        Game game=new Game();
        VistaConsola vista=new VistaConsola();

        do { 

            option=Byte.parseByte(vista.leerTexto("\nDijita la opción que desees:\n1. Mostrar estado actual del juego\n2. Abrir juego\n3. Cerrar juego\n4. Salir\n\n"));

            switch (option) {
                case 1 -> {
                    vista.mostrarInformacion(game.action());
                    break;
                }
                case 2 -> {
                    game.setState(new Loading());
                    break;
                }
                case 3 -> {
                    game.setState(new Close());
                    break;
                }
                case 4 -> {
                    break;
                }
            }

        } while (option!=4);
        System.exit(0);

    }

}
