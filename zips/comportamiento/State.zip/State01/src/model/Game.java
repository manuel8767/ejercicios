package model;

public class Game {

    private State state;

    public Game() {
        this.setState(new Close());
    }

    public void setState(State state) {
        this.state = state;
    }

    public String action() {
        return state.action(this);
    }

}
