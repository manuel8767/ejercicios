package model;

public abstract class State {

    public abstract String action(Game game);

}
