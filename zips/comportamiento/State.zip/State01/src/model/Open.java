package model;

public class Open extends State {

    @Override
    public String action(Game game) {
        return "\nJuego abierto.";
    }

}
