package model;

public class Close extends State {

    @Override
    public String action(Game game) {
        return "\nJuego cerrado.";
    }

}
