package model;

public class Loading extends State {

    @Override
    public String action(Game game) {
        game.setState(new Open());
        return "\nCargando juego...";
    }

}
