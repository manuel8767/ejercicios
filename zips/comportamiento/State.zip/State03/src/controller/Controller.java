package controller;

import model.Pause;
import model.Play;
import model.Reproductor;
import view.VistaConsola;

public class Controller {

    public void run() {

        byte option;
        Reproductor reproductor=new Reproductor();
        VistaConsola vista=new VistaConsola();

        do { 

            option=Byte.parseByte(vista.leerTexto("\nDijita la opción que desees:\n1. Mostrar estado actual del reproductor\n2. Reanudar reproductor\n3. Pausar reproductor\n4. Salir\n\n"));

            switch (option) {
                case 1 -> {
                    vista.mostrarInformacion(reproductor.action());
                    break;
                }
                case 2 -> {
                    reproductor.setState(new Play());
                    break;
                }
                case 3 -> {
                    reproductor.setState(new Pause());
                    break;
                }
                case 4 -> {
                    break;
                }
            }

        } while (option!=4);
        System.exit(0);

    }

}
