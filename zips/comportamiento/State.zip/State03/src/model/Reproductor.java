package model;

public class Reproductor {

    private State state;

    public Reproductor() {
        this.setState(new Pause());
    }

    public void setState(State state) {
        this.state = state;
    }

    public String action() {
        return state.action(this);
    }

}
