package model;

public class Pause extends State {

    @Override
    public String action(Reproductor reproductor) {
        return "\nReproductor pausado.";
    }

}
