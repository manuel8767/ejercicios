package model;

public class Play extends State {

    @Override
    public String action(Reproductor reproductor) {
        return "\nReproductor reanudado.";
    }

}
