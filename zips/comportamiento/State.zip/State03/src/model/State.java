package model;

public abstract class State {

    public abstract String action(Reproductor reproductor);

}
