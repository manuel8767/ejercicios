package model;

import java.util.ArrayList;
import java.util.Iterator;

public class Curso {
    private ArrayList<Estudiante> estudiantes = new ArrayList<>();

    public void agregar(Estudiante e) {
        estudiantes.add(e);
    }

    public Iterator<Estudiante> crearIterador() {
        return estudiantes.iterator();
    }
}