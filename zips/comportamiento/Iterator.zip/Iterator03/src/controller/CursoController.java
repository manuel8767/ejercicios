package controller;

import java.util.Iterator;
import model.Curso;
import model.Estudiante;

public class CursoController {
    private Curso curso;

    public CursoController(Curso curso) {
        this.curso = curso;
    }

    public Iterator<Estudiante> getIterador() {
        return curso.crearIterador();
    }
}