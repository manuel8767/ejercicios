package controller;

import java.util.Iterator;
import model.Curso;
import model.Estudiante;
import view.CursoView;

public class TestCursoManual {
    public static void main(String[] args) {
        Curso curso = new Curso();
        curso.agregar(new Estudiante("Laura"));
        curso.agregar(new Estudiante("Carlos"));

        CursoController controller = new CursoController(curso);
        CursoView view = new CursoView();

        Iterator<Estudiante> it = controller.getIterador();
        while (it.hasNext()) {
            view.mostrar(it.next());
        }
    }
}