package view;

import model.Estudiante;

public class CursoView {
    public void mostrar(Estudiante e) {
        System.out.println("Estudiante: " + e.getNombre());
    }
}