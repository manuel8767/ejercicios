package model;

import java.util.ArrayList;
import java.util.Iterator;

public class Biblioteca {
    private ArrayList<Libro> libros = new ArrayList<>();

    public void agregarLibro(Libro libro) {
        libros.add(libro);
    }

    public Iterator<Libro> crearIterador() {
        return libros.iterator();
    }
}