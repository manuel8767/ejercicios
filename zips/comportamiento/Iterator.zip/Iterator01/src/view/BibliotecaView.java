package view;

import model.Libro;

public class BibliotecaView {
    public void mostrarLibro(Libro libro) {
        System.out.println("Libro: " + libro.getTitulo());
    }
}