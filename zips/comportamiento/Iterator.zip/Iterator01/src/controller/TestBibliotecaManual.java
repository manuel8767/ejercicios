package controller;

import java.util.Iterator;
import model.Biblioteca;
import model.Libro;
import view.BibliotecaView;

public class TestBibliotecaManual {
    public static void main(String[] args) {
        Biblioteca biblioteca = new Biblioteca();
        biblioteca.agregarLibro(new Libro("1984"));
        biblioteca.agregarLibro(new Libro("El Principito"));
        biblioteca.agregarLibro(new Libro("Don Quijote"));

        BibliotecaController controller = new BibliotecaController(biblioteca);
        BibliotecaView view = new BibliotecaView();

        Iterator<Libro> it = controller.obtenerIterador();
        while (it.hasNext()) {
            view.mostrarLibro(it.next());
        }
    }
}