package controller;

import java.util.Iterator;
import model.Biblioteca;
import model.Libro;

public class BibliotecaController {
    private Biblioteca biblioteca;

    public BibliotecaController(Biblioteca biblioteca) {
        this.biblioteca = biblioteca;
    }

    public Iterator<Libro> obtenerIterador() {
        return biblioteca.crearIterador();
    }
}