package view;
 
import model.Plato;

public class MenuView {
    public void mostrarPlato(Plato p) {
        System.out.println("Plato: " + p.getNombre());
    }
}