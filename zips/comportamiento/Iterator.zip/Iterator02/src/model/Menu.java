package model;

import java.util.ArrayList;
import java.util.Iterator;

public class Menu {
    private ArrayList<Plato> platos = new ArrayList<>();

    public void agregarPlato(Plato p) {
        platos.add(p);
    }

    public Iterator<Plato> crearIterador() {
        return platos.iterator();
    }
}