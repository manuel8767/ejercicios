package model;

public class Plato {
    private String nombre;

    public Plato(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }
}