package controller;

import java.util.Iterator;
import model.Menu;
import model.Plato;
import view.MenuView;

public class TestMenuManual {
    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.agregarPlato(new Plato("Arroz con pollo"));
        menu.agregarPlato(new Plato("Pasta al pesto"));

        MenuController controller = new MenuController(menu);
        MenuView view = new MenuView();

        Iterator<Plato> it = controller.getIterador();
        while (it.hasNext()) {
            view.mostrarPlato(it.next());
        }
    }
}