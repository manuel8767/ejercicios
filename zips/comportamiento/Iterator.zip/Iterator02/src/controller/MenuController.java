package controller;

import java.util.Iterator;
import model.Menu;
import model.Plato;

public class MenuController {
    private Menu menu;

    public MenuController(Menu menu) {
        this.menu = menu;
    }

    public Iterator<Plato> getIterador() {
        return menu.crearIterador();
    }
}