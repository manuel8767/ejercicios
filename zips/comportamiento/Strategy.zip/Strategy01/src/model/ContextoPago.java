package model;

public class ContextoPago {
    private EstrategiaPago estrategia;

    public void setEstrategia(EstrategiaPago estrategia) {
        this.estrategia = estrategia;
    }

    public void realizarPago(double cantidad) {
        estrategia.pagar(cantidad);
    }
}