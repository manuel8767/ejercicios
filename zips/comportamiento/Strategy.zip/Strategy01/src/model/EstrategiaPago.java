package model;

public interface EstrategiaPago {
    void pagar(double cantidad);
}