package model;

public class PagoTarjeta implements EstrategiaPago {
    public void pagar(double cantidad) {
        System.out.println("Pagando $" + cantidad + " con tarjeta");
    }
}