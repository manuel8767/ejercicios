package model;

public class PagoEfectivo implements EstrategiaPago {
    public void pagar(double cantidad) {
        System.out.println("Pagando $" + cantidad + " en efectivo");
    }
}