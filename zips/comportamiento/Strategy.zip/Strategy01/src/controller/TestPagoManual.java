package controller;

import model.ContextoPago;
import model.PagoEfectivo;
import model.PagoTarjeta;
import view.PagoView;

public class TestPagoManual {
    public static void main(String[] args) {
        ContextoPago contexto = new ContextoPago();
        PagoController controller = new PagoController(contexto);
        PagoView vista = new PagoView();

        vista.mostrar("Pago en efectivo:");
        contexto.setEstrategia(new PagoEfectivo());
        controller.pagar(100.0);

        vista.mostrar("Pago con tarjeta:");
        contexto.setEstrategia(new PagoTarjeta());
        controller.pagar(250.5);
    }
}