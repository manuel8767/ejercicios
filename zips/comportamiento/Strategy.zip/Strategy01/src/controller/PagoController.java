package controller;

import model.ContextoPago;

public class PagoController {
    private ContextoPago contexto;

    public PagoController(ContextoPago contexto) {
        this.contexto = contexto;
    }

    public void pagar(double cantidad) {
        contexto.realizarPago(cantidad);
    }
}