package view;

public class PagoView {
    public void mostrar(String mensaje) {
        System.out.println("Vista: " + mensaje);
    }
}