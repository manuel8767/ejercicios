package model;

public class ContextoCompresion {
    private EstrategiaCompresion estrategia;

    public void setEstrategia(EstrategiaCompresion estrategia) {
        this.estrategia = estrategia;
    }

    public void comprimirArchivo(String archivo) {
        estrategia.comprimir(archivo);
    }
}