package model;

public interface EstrategiaCompresion {
    void comprimir(String archivo);
}