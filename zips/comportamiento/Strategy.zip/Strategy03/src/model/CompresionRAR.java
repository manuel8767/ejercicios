package model;

public class CompresionRAR implements EstrategiaCompresion {
    public void comprimir(String archivo) {
        System.out.println("Comprimido " + archivo + " usando RAR");
    }
}