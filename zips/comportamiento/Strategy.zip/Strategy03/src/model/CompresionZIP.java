package model;

public class CompresionZIP implements EstrategiaCompresion {
    public void comprimir(String archivo) {
        System.out.println("Comprimido " + archivo + " usando ZIP");
    }
}