package controller;

import model.ContextoCompresion;

public class CompresionController {
    private ContextoCompresion contexto;

    public CompresionController(ContextoCompresion contexto) {
        this.contexto = contexto;
    }

    public void comprimir(String archivo) {
        contexto.comprimirArchivo(archivo);
    }
}