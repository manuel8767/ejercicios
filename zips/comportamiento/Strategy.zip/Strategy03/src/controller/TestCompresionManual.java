package controller;

import model.CompresionRAR;
import model.CompresionZIP;
import model.ContextoCompresion;
import view.CompresionView;

public class TestCompresionManual {
    public static void main(String[] args) {
        ContextoCompresion contexto = new ContextoCompresion();
        CompresionController controller = new CompresionController(contexto);
        CompresionView vista = new CompresionView();

        vista.mostrar("Usando estrategia ZIP:");
        contexto.setEstrategia(new CompresionZIP());
        controller.comprimir("documento.txt");

        vista.mostrar("Usando estrategia RAR:");
        contexto.setEstrategia(new CompresionRAR());
        controller.comprimir("documento.txt");
    }
}