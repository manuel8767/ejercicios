package view;

public class CompresionView {
    public void mostrar(String mensaje) {
        System.out.println("Vista: " + mensaje);
    }
}