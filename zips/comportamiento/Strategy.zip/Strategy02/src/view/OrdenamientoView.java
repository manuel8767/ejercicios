package view;

public class OrdenamientoView {
    public void mostrar(String mensaje) {
        System.out.println("Vista: " + mensaje);
    }
}