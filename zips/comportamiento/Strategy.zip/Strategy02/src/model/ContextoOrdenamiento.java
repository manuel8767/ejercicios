package model;

public class ContextoOrdenamiento {
    private EstrategiaOrdenamiento estrategia;

    public void setEstrategia(EstrategiaOrdenamiento estrategia) {
        this.estrategia = estrategia;
    }

    public void ordenar(int[] arreglo) {
        estrategia.ordenar(arreglo);
    }
}