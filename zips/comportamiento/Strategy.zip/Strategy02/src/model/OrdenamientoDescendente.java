package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class OrdenamientoDescendente implements EstrategiaOrdenamiento {
    public void ordenar(int[] arreglo) {
        List<Integer> lista = new ArrayList<>();
        for (int i : arreglo) lista.add(i);
        lista.sort(Collections.reverseOrder());

        System.out.print("Ordenado descendente: ");
        for (int i : lista) {
            System.out.print(i + " ");
        }
        System.out.println();
    }
}