package model;

import java.util.Arrays;

public class OrdenamientoAscendente implements EstrategiaOrdenamiento {
    public void ordenar(int[] arreglo) {
        Arrays.sort(arreglo);
        System.out.println("Ordenado ascendente: " + Arrays.toString(arreglo));
    }
}