package model;

public interface EstrategiaOrdenamiento {
    void ordenar(int[] arreglo);
}