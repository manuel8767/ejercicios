package controller;

import model.ContextoOrdenamiento;

public class OrdenamientoController {
    private ContextoOrdenamiento contexto;

    public OrdenamientoController(ContextoOrdenamiento contexto) {
        this.contexto = contexto;
    }

    public void ordenar(int[] arreglo) {
        contexto.ordenar(arreglo);
    }
}
