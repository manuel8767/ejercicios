package controller;

import model.ContextoOrdenamiento;
import model.OrdenamientoAscendente;
import model.OrdenamientoDescendente;
import view.OrdenamientoView;

public class TestOrdenamientoManual {
    public static void main(String[] args) {
        ContextoOrdenamiento contexto = new ContextoOrdenamiento();
        OrdenamientoController controller = new OrdenamientoController(contexto);
        OrdenamientoView vista = new OrdenamientoView();

        int[] datos = {5, 2, 9, 1, 7};

        vista.mostrar("Orden ascendente:");
        contexto.setEstrategia(new OrdenamientoAscendente());
        controller.ordenar(datos.clone());

        vista.mostrar("Orden descendente:");
        contexto.setEstrategia(new OrdenamientoDescendente());
        controller.ordenar(datos.clone());
    }
}