package controller;

import model.BebidaCaliente;

public class BebidaController {
    private BebidaCaliente bebida;

    public BebidaController(BebidaCaliente bebida) {
        this.bebida = bebida;
    }

    public void preparar() {
        bebida.preparar();
    }
}