package controller;

import model.Cafe;
import model.Te;
import view.BebidaView;

public class TestBebidaManual {
    public static void main(String[] args) {
        BebidaView vista = new BebidaView();

        vista.mostrar("Preparando té:");
        BebidaController cTe = new BebidaController(new Te());
        cTe.preparar();

        vista.mostrar("Preparando café:");
        BebidaController cCafe = new BebidaController(new Cafe());
        cCafe.preparar();
    }
}