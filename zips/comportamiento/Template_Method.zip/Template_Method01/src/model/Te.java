package model;

public class Te extends BebidaCaliente {
    protected void agregarIngrediente() {
        System.out.println("Agregando bolsita de té.");
    }
}