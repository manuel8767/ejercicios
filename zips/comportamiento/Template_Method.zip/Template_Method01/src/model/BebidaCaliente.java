package model;

public abstract class BebidaCaliente {
    public final void preparar() {
        hervirAgua();
        agregarIngrediente();
        servir();
    }

    protected void hervirAgua() {
        System.out.println("Hirviendo agua...");
    }

    protected abstract void agregarIngrediente();

    protected void servir() {
        System.out.println("Sirviendo en taza.");
    }
}