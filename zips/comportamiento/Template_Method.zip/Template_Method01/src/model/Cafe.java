package model;

public class Cafe extends BebidaCaliente {
    protected void agregarIngrediente() {
        System.out.println("Agregando café instantáneo.");
    }
}