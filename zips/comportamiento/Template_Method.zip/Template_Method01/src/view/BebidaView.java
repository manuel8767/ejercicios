package view;

public class BebidaView {
    public void mostrar(String mensaje) {
        System.out.println("Vista: " + mensaje);
    }
}