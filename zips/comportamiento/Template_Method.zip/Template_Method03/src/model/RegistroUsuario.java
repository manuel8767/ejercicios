package model;

public abstract class RegistroUsuario {
    public final void registrar() {
        ingresarDatos();
        validarDatos();
        guardarEnBaseDeDatos();
        mostrarConfirmacion();
    }

    protected abstract void ingresarDatos();
    protected abstract void validarDatos();

    protected void guardarEnBaseDeDatos() {
        System.out.println("Guardando usuario en base de datos...");
    }

    protected void mostrarConfirmacion() {
        System.out.println("Usuario registrado correctamente.");
    }
}