package model;

public class RegistroAdministrador extends RegistroUsuario {
    protected void ingresarDatos() {
        System.out.println("Ingresando datos de administrador...");
    }

    protected void validarDatos() {
        System.out.println("Verificando permisos del administrador...");
    }
}