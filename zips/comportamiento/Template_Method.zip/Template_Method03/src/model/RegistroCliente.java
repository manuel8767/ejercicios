package model;

public class RegistroCliente extends RegistroUsuario {
    protected void ingresarDatos() {
        System.out.println("Ingresando datos de cliente...");
    }

    protected void validarDatos() {
        System.out.println("Validando datos del cliente...");
    }
}