package view;

public class RegistroView {
    public void mostrar(String mensaje) {
        System.out.println("Vista: " + mensaje);
    }
}