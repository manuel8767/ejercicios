package controller;

import model.RegistroUsuario;

public class RegistroController {
    private RegistroUsuario registro;

    public RegistroController(RegistroUsuario registro) {
        this.registro = registro;
    }

    public void ejecutarRegistro() {
        registro.registrar();
    }
}