package controller;

import model.RegistroAdministrador;
import model.RegistroCliente;
import view.RegistroView;

public class TestRegistroManual {
    public static void main(String[] args) {
        RegistroView vista = new RegistroView();

        vista.mostrar("Registro de cliente:");
        RegistroController cCliente = new RegistroController(new RegistroCliente());
        cCliente.ejecutarRegistro();

        vista.mostrar("Registro de administrador:");
        RegistroController cAdmin = new RegistroController(new RegistroAdministrador());
        cAdmin.ejecutarRegistro();
    }
}