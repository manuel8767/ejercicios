package model;

public abstract class Reporte {
    public final void generar() {
        obtenerDatos();
        procesarDatos();
        imprimirReporte();
    }

    protected abstract void obtenerDatos();
    protected abstract void procesarDatos();

    protected void imprimirReporte() {
        System.out.println("Imprimiendo reporte...");
    }
}