package model;

public class ReporteUsuarios extends Reporte {
    protected void obtenerDatos() {
        System.out.println("Obteniendo datos de usuarios...");
    }

    protected void procesarDatos() {
        System.out.println("Analizando comportamiento de usuarios...");
    }
}