package model;

public class ReporteVentas extends Reporte {
    protected void obtenerDatos() {
        System.out.println("Obteniendo datos de ventas...");
    }

    protected void procesarDatos() {
        System.out.println("Calculando total de ventas...");
    }
}