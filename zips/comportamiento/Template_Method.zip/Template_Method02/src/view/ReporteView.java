package view;

public class ReporteView {
    public void mostrar(String mensaje) {
        System.out.println("Vista: " + mensaje);
    }
}