package controller;

import model.ReporteUsuarios;
import model.ReporteVentas;
import view.ReporteView;

public class TestReporteManual {
    public static void main(String[] args) {
        ReporteView vista = new ReporteView();

        vista.mostrar("Generando reporte de ventas:");
        ReporteController cVentas = new ReporteController(new ReporteVentas());
        cVentas.generar();

        vista.mostrar("Generando reporte de usuarios:");
        ReporteController cUsuarios = new ReporteController(new ReporteUsuarios());
        cUsuarios.generar();
    }
}