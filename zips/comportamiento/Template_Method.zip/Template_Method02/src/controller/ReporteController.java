package controller;

import model.Reporte;

public class ReporteController {
    private Reporte reporte;

    public ReporteController(Reporte reporte) {
        this.reporte = reporte;
    }

    public void generar() {
        reporte.generar();
    }
}