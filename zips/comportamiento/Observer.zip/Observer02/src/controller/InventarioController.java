package controller;

import model.Inventario;

public class InventarioController {
    private Inventario inventario;

    public InventarioController(Inventario inventario) {
        this.inventario = inventario;
    }

    public void vender(String producto, int cantidad) {
        inventario.vender(producto, cantidad);
    }
}