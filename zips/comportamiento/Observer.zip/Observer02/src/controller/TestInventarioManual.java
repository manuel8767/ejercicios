package controller;

import model.Inventario;
import view.AlertaStock;

public class TestInventarioManual {
    public static void main(String[] args) {
        Inventario inventario = new Inventario();
        AlertaStock alerta = new AlertaStock();

        inventario.agregarObservador(alerta);

        InventarioController controller = new InventarioController(inventario);

        controller.vender("Manzanas", 10);
        controller.vender("Bananas", 5);
    }
}