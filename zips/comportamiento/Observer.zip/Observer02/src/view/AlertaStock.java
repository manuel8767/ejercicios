package view;

import model.ObservadorStock;

public class AlertaStock implements ObservadorStock {
    public void notificar(String producto, int cantidad) {
        System.out.println("Alerta: se vendieron " + cantidad + " unidades de " + producto);
    }
}