package model;

public interface ObservadorStock {
    void notificar(String producto, int cantidad);
}