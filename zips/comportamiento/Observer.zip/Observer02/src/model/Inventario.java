package model;

import java.util.ArrayList;
import java.util.List;

public class Inventario {
    private List<ObservadorStock> observadores = new ArrayList<>();

    public void agregarObservador(ObservadorStock o) {
        observadores.add(o);
    }

    public void vender(String producto, int cantidad) {
        System.out.println("Vendiendo " + cantidad + " de " + producto);
        notificar(producto, cantidad);
    }

    private void notificar(String producto, int cantidad) {
        for (ObservadorStock o : observadores) {
            o.notificar(producto, cantidad);
        }
    }
}