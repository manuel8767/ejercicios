package model;

public interface ObservadorTemperatura {
    void actualizar(int temperatura);
}