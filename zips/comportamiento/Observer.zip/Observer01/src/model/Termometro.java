package model;

import java.util.ArrayList;
import java.util.List;

public class Termometro {
    private List<ObservadorTemperatura> observadores = new ArrayList<>();
    private int temperatura;

    public void agregarObservador(ObservadorTemperatura o) {
        observadores.add(o);
    }

    public void setTemperatura(int nuevaTemp) {
        this.temperatura = nuevaTemp;
        notificar();
    }

    private void notificar() {
        for (ObservadorTemperatura o : observadores) {
            o.actualizar(temperatura);
        }
    }
}