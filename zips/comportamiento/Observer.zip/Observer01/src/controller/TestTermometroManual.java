package controller;

import model.Termometro;
import view.DisplayTemperatura;

public class TestTermometroManual {
    public static void main(String[] args) {
        Termometro termometro = new Termometro();

        DisplayTemperatura vista1 = new DisplayTemperatura("Vista A");
        DisplayTemperatura vista2 = new DisplayTemperatura("Vista B");

        termometro.agregarObservador(vista1);
        termometro.agregarObservador(vista2);

        TemperaturaController controller = new TemperaturaController(termometro);

        controller.cambiarTemperatura(25);
        controller.cambiarTemperatura(30);
    }
}