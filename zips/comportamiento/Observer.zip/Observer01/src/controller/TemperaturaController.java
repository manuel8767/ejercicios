package controller;

import model.Termometro;

public class TemperaturaController {
    private Termometro termometro;

    public TemperaturaController(Termometro termometro) {
        this.termometro = termometro;
    }

    public void cambiarTemperatura(int nuevaTemp) {
        termometro.setTemperatura(nuevaTemp);
    }
}