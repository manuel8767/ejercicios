package view;

import model.ObservadorTemperatura;

public class DisplayTemperatura implements ObservadorTemperatura {
    private String nombre;

    public DisplayTemperatura(String nombre) {
        this.nombre = nombre;
    }

    public void actualizar(int temperatura) {
        System.out.println(nombre + ": temperatura actual = " + temperatura + "°C");
    }
}