package view;


import model.ObservadorClick;

public class MensajeClick implements ObservadorClick {
    private String mensaje;

    public MensajeClick(String mensaje) {
        this.mensaje = mensaje;
    }

    public void alHacerClick() {
        System.out.println("Listener: " + mensaje);
    }
}