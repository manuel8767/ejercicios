package controller;

import model.Boton;

public class BotonController {
    private Boton boton;

    public BotonController(Boton boton) {
        this.boton = boton;
    }

    public void presionar() {
        boton.click();
    }
}