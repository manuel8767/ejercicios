package controller;

import model.Boton;
import view.MensajeClick;

public class TestBotonManual {
    public static void main(String[] args) {
        Boton boton = new Boton();

        MensajeClick listener1 = new MensajeClick("Se abrió el menú");
        MensajeClick listener2 = new MensajeClick("Se guardó el archivo");

        boton.agregarListener(listener1);
        boton.agregarListener(listener2);

        BotonController controller = new BotonController(boton);

        controller.presionar();
    }
}