package model;

public interface ObservadorClick {
    void alHacerClick();
}