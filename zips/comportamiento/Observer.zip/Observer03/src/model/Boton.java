package model;

import java.util.ArrayList;
import java.util.List;

public class Boton {
    private List<ObservadorClick> observadores = new ArrayList<>();

    public void agregarListener(ObservadorClick o) {
        observadores.add(o);
    }

    public void click() {
        System.out.println("Botón fue presionado");
        for (ObservadorClick o : observadores) {
            o.alHacerClick();
        }
    }
}