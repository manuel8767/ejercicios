package controller;

import model.Circle;
import model.Shape;
import model.Square;
import model.Visitor;
import model.VisitorArea;
import model.VisitorPerimeter;
import view.VistaConsola;

public class Controller {

    public void run() {

        Shape circle=new Circle(15.2);
        Shape square=new Square(56.7);
        Visitor visitorArea=new VisitorArea();
        Visitor visitorPerimeter=new VisitorPerimeter();
        VistaConsola vista=new VistaConsola();

        vista.mostrarInformacion("Areá del círculo: ");
        vista.mostrarValor(circle.acceptVisitor(visitorArea));
        vista.mostrarInformacion("Perímetro del círculo: ");
        vista.mostrarValor(circle.acceptVisitor(visitorPerimeter));
        vista.mostrarInformacion("Areá del cuadrado: ");
        vista.mostrarValor(square.acceptVisitor(visitorArea));
        vista.mostrarInformacion("Perímetro del cuadrado: ");
        vista.mostrarValor(square.acceptVisitor(visitorPerimeter));

    }

}
