package model;

public abstract class Visitor {

    protected Double area, perimeter;

    public abstract Double visitCircle(Circle circle);
    public abstract Double visitSquare(Square square);

}
