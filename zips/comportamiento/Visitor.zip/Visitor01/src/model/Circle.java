package model;

public class Circle extends Shape {

    private Double radio;

    public Circle(Double radio) {
        this.radio = radio;
    }

    @Override
    public Double acceptVisitor(Visitor visitor) {
        return visitor.visitCircle(this);
    }

    public Double getRadio() {
        return radio;
    }

}
