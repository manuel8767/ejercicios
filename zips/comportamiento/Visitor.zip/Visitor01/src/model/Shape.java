package model;

public abstract class Shape {

    public abstract Double acceptVisitor(Visitor visitor);

}
