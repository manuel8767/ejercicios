package model;

public class VisitorArea extends Visitor {

    @Override
    public Double visitCircle(Circle circle) {
        area=Math.PI*circle.getRadio()*circle.getRadio();
        return area;
    }

    @Override
    public Double visitSquare(Square square) {
        area=square.getSide()*square.getSide();
        return area;
    }

}
