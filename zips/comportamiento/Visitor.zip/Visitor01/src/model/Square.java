package model;

public class Square extends Shape {

    private Double side;

    public Square(Double side) {
        this.side = side;
    }

    @Override
    public Double acceptVisitor(Visitor visitor) {
        return visitor.visitSquare(this);
    }

    public Double getSide() {
        return side;
    }

}
