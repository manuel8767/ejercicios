package model;

public class VisitorPerimeter extends Visitor {

    @Override
    public Double visitCircle(Circle circle) {
        perimeter=2*Math.PI*circle.getRadio();
        return perimeter;
    }

    @Override
    public Double visitSquare(Square square) {
        perimeter=4*square.getSide();
        return perimeter;
    }

}
