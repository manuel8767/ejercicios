package controller;

import model.School;
import model.Visitor;
import model.VisitorAverage;
import view.VistaConsola;

public class Controller {

    public void run() {

        double grade;
        VistaConsola vista=new VistaConsola();

        grade=Double.parseDouble(vista.leerTexto("¿Cúal nota de talleres deseas obtener? "));
        School school=new School(grade);
        Visitor visitorAverage=new VisitorAverage();

        vista.mostrarInformacion("\nPara obtener dicha nota, necesitas sacar ");
        vista.mostrarValor(visitorAverage.visitSchool(school));
        vista.mostrarInformacion(" en cada uno de los próximos cinco taleres.");

    }

}
