package model;

public class School extends Grades {

    private double grade;

    public School(double grade) {
        this.grade = grade;
    }

    @Override
    public Double acceptVisitor(Visitor visitor) {
        return visitor.visitSchool(this);
    }

    public double getGrade() {
        return grade;
    }

}
