package model;

public abstract class Grades {

    public abstract Double acceptVisitor(Visitor visitor);

}
