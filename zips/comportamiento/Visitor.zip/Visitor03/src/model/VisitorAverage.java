package model;

public class VisitorAverage extends Visitor {

    @Override
    public Double visitSchool(School school) {
        return school.getGrade()/5;
    }

}
