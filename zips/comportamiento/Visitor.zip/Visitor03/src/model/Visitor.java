package model;

public abstract class Visitor {

    public abstract Double visitSchool(School school);

}
