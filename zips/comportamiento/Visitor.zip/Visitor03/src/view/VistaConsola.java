package view;

import java.util.Scanner;

public class VistaConsola {

    private Scanner sc;

	public VistaConsola() {
		sc = new Scanner(System.in);
	}

	public void mostrarValor(double value) {
		System.out.print(value);
	}

	public void mostrarInformacion(String mensaje) {
		System.out.print(mensaje);
	}

	public String leerTexto(String mensaje) {
		String info;
		System.out.print(mensaje);
		info=sc.nextLine();
		return info;
	}

}
