package model;

public class VisitorTicketPrice extends Visitor {

    @Override
    public int visitCinema(Cinema cinema) {
        return cinema.getAmount()*cinema.getPrice();
    }

}
