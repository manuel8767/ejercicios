package model;

public abstract class Visitor {

    protected Double area, perimeter;

    public abstract int visitCinema(Cinema cinema);

}
