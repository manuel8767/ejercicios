package model;

public abstract class Ticket {

    public abstract int acceptVisitor(Visitor visitor);

}
