package model;

public class Cinema extends Ticket {

    private int price;
    private int amount;

    public Cinema(int price, int amount) {
        this.price = price;
        this.amount = amount;
    }

    @Override
    public int acceptVisitor(Visitor visitor) {
        return visitor.visitCinema(this);
    }

    public int getPrice() {
        return price;
    }

    public int getAmount() {
        return amount;
    }

}
