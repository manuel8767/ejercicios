package controller;

import model.Cinema;
import model.Visitor;
import model.VisitorTicketPrice;
import view.VistaConsola;

public class Controller {

    public void run() {

        Visitor visitorArea=new VisitorTicketPrice();
        VistaConsola vista=new VistaConsola();
        int amount, price=15000;

        amount=Integer.parseInt(vista.leerTexto("¿Cuantás boletas deseas? "));
        Cinema cinema=new Cinema(price, amount);
        vista.mostrarInformacion("El total del pedido es de ");
        vista.mostrarValor(visitorArea.visitCinema(cinema));
        vista.mostrarInformacion(" pesos.");

    }

}
