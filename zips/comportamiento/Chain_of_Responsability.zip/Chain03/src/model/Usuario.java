package model;

public class Usuario {
    public String nombre;
    public String email;
    public int edad;

    public Usuario(String nombre, String email, int edad) {
        this.nombre = nombre;
        this.email = email;
        this.edad = edad;
    }
}