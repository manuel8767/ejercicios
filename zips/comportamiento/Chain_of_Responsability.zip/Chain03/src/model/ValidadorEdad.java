package model;

public class ValidadorEdad extends Validador {
    public boolean validar(Usuario u) {
        if (u.edad < 18) {
            System.out.println("Edad no permitida");
            return false;
        }
        System.out.println("Usuario válido");
        return true;
    }
}