package model;

public class ValidadorNombre extends Validador {
    public boolean validar(Usuario u) {
        if (u.nombre == null || u.nombre.isEmpty()) {
            System.out.println("Nombre inválido");
            return false;
        } else if (siguiente != null) {
            return siguiente.validar(u);
        }
        return true;
    }
}