package model;

public class ValidadorEmail extends Validador {
    public boolean validar(Usuario u) {
        if (!u.email.contains("@")) {
            System.out.println("Email inválido");
            return false;
        } else if (siguiente != null) {
            return siguiente.validar(u);
        }
        return true;
    }
}