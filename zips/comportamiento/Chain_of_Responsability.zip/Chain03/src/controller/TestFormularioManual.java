package controller;

import model.Usuario;
import model.Validador;
import model.ValidadorEdad;
import model.ValidadorEmail;
import model.ValidadorNombre;
import view.FormularioView;

public class TestFormularioManual {
    public static void main(String[] args) {
        Validador nombre = new ValidadorNombre();
        Validador email = new ValidadorEmail();
        Validador edad = new ValidadorEdad();

        nombre.setSiguiente(email);
        email.setSiguiente(edad);

        FormularioController controller = new FormularioController(nombre);
        FormularioView vista = new FormularioView();

        Usuario u1 = new Usuario("Ana", "ana@mail.com", 20);
        Usuario u2 = new Usuario("", "correo.com", 17);

        vista.mostrar("Validando usuario 1:");
        controller.procesar(u1);

        vista.mostrar("Validando usuario 2:");
        controller.procesar(u2);
    }
}