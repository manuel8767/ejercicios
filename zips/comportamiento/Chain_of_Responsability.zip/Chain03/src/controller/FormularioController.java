package controller;

import model.Usuario;
import model.Validador;

public class FormularioController {
    private Validador validador;

    public FormularioController(Validador validador) {
        this.validador = validador;
    }

    public void procesar(Usuario u) {
        validador.validar(u);
    }
}