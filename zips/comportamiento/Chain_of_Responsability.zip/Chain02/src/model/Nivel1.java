package model;

public class Nivel1 extends Manejador {
    public void manejar(Solicitud s) {
        if (s.getTipo().equalsIgnoreCase("basico")) {
            System.out.println("Nivel 1 resolvió: " + s.getTipo());
        } else if (siguiente != null) {
            siguiente.manejar(s);
        }
    }
}