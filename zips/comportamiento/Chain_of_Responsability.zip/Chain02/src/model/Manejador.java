package model;

public abstract class Manejador {
    protected Manejador siguiente;

    public void setSiguiente(Manejador siguiente) {
        this.siguiente = siguiente;
    }

    public abstract void manejar(Solicitud s);
}