package model;

public class Solicitud {
    private String tipo;

    public Solicitud(String tipo) {
        this.tipo = tipo;
    }

    public String getTipo() {
        return tipo;
    }
}