package model;

public class Nivel2 extends Manejador {
    public void manejar(Solicitud s) {
        if (s.getTipo().equalsIgnoreCase("medio")) {
            System.out.println("Nivel 2 resolvió: " + s.getTipo());
        } else if (siguiente != null) {
            siguiente.manejar(s);
        }
    }
}