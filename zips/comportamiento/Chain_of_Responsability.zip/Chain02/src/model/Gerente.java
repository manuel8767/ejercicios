package model;

public class Gerente extends Manejador {
    public void manejar(Solicitud s) {
        System.out.println("Gerente resolvió: " + s.getTipo());
    }
}