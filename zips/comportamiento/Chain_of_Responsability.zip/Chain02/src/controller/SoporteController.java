package controller;

import model.Manejador;
import model.Solicitud;

public class SoporteController {
    private Manejador cadena;

    public SoporteController(Manejador cadena) {
        this.cadena = cadena;
    }

    public void procesarSolicitud(Solicitud s) {
        cadena.manejar(s);
    }
}
