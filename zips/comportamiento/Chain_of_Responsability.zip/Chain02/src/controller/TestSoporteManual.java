package controller;

import model.Gerente;
import model.Manejador;
import model.Nivel1;
import model.Nivel2;
import model.Solicitud;
import view.SoporteView;

public class TestSoporteManual {
    public static void main(String[] args) {
        Manejador n1 = new Nivel1();
        Manejador n2 = new Nivel2();
        Manejador gerente = new Gerente();

        n1.setSiguiente(n2);
        n2.setSiguiente(gerente);

        SoporteController controller = new SoporteController(n1);
        SoporteView vista = new SoporteView();

        vista.mostrar("Solicitud básica:");
        controller.procesarSolicitud(new Solicitud("básico"));

        vista.mostrar("Solicitud media:");
        controller.procesarSolicitud(new Solicitud("medio"));

        vista.mostrar("Solicitud crítica:");
        controller.procesarSolicitud(new Solicitud("crítico"));
    }
}