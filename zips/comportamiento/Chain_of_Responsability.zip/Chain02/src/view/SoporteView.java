package view;

public class SoporteView {
    public void mostrar(String msg) {
        System.out.println("Vista: " + msg);
    }
}