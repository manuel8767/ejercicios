package model;

public class Correo {
    private String asunto;

    public Correo(String asunto) {
        this.asunto = asunto;
    }

    public String getAsunto() {
        return asunto;
    }
}