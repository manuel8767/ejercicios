package model;

public class FiltroSpam extends Filtro {
    public void procesar(Correo correo) {
        if (correo.getAsunto().toLowerCase().contains("ganaste")) {
            System.out.println("Detectado SPAM: " + correo.getAsunto());
        } else if (siguiente != null) {
            siguiente.procesar(correo);
        }
    }
}