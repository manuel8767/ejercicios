package model;

public abstract class Filtro {
    protected Filtro siguiente;

    public void setSiguiente(Filtro siguiente) {
        this.siguiente = siguiente;
    }

    public abstract void procesar(Correo correo);
}