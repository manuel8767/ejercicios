package model;

public class FiltroTrabajo extends Filtro {
    public void procesar(Correo correo) {
        if (correo.getAsunto().toLowerCase().contains("reporte")) {
            System.out.println("Clasificado como trabajo: " + correo.getAsunto());
        } else if (siguiente != null) {
            siguiente.procesar(correo);
        }
    }
}