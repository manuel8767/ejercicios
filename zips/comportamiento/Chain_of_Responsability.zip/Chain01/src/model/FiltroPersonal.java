package model;

public class FiltroPersonal extends Filtro {
    public void procesar(Correo correo) {
        System.out.println("Clasificado como personal: " + correo.getAsunto());
    }
}