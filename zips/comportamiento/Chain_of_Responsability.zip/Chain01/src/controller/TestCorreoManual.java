package controller;

import model.Correo;
import model.Filtro;
import model.FiltroPersonal;
import model.FiltroSpam;
import model.FiltroTrabajo;
import view.FiltroView;

public class TestCorreoManual {
    public static void main(String[] args) {
        Filtro spam = new FiltroSpam();
        Filtro trabajo = new FiltroTrabajo();
        Filtro personal = new FiltroPersonal();

        spam.setSiguiente(trabajo);
        trabajo.setSiguiente(personal);

        FiltroController controller = new FiltroController(spam);
        FiltroView vista = new FiltroView();

        Correo c1 = new Correo("¡Ganaste un premio!");
        Correo c2 = new Correo("Reporte mensual");
        Correo c3 = new Correo("Vamos al cine");

        vista.mostrar("Procesando correo 1:");
        controller.procesarCorreo(c1);

        vista.mostrar("Procesando correo 2:");
        controller.procesarCorreo(c2);

        vista.mostrar("Procesando correo 3:");
        controller.procesarCorreo(c3);
    }
}