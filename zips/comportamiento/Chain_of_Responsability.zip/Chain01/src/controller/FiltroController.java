package controller;

import model.Correo;
import model.Filtro;

public class FiltroController {
    private Filtro cadena;

    public FiltroController(Filtro cadena) {
        this.cadena = cadena;
    }

    public void procesarCorreo(Correo correo) {
        cadena.procesar(correo);
    }
}