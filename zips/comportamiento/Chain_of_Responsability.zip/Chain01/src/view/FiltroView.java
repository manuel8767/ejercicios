package view;

public class FiltroView {
    public void mostrar(String mensaje) {
        System.out.println("Vista: " + mensaje);
    }
}