package controller;

import model.Animal;
import view.VistaConsola;

public class Controller {

    public void run() {

        VistaConsola vista=new VistaConsola();
        byte option;
        String name="White Shark", diet="Seals", habitat="Ocean";
        Animal animal=new Animal(name, diet, habitat);

        do { 

            option=Byte.parseByte(vista.leerTexto("\nDijita la opción que desees:\n1. Ver animal por defecto\n2. Cambiar animal por defecto\n3. Salir\n\n"));

            switch (option) {
                case 1-> {
                    vista.mostrarInformacion("\nNombre: "+name+"\nDieta: "+diet+"\nHabitat: "+habitat);
                    break;
                }
                case 2-> {
                    name=vista.leerTexto("\nEscribe el nombre del nuevo animal: ");
                    diet=vista.leerTexto("Escribe la dieta del nuevo animal: ");
                    habitat=vista.leerTexto("Escribe el habitat del nuevo animal: ");
                    animal.clone();
                    animal.setName(name);
                    animal.setDiet(diet);
                    animal.setHabitat(habitat);
                    break;
                }
                case 3-> {
                    break;
                }
            }
        } while (option!=3);
        System.exit(0);

    }

}
