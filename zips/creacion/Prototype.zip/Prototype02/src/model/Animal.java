package model;

public class Animal implements Cloneable { 

    private String name;
    private String diet;
    private String habitat;

    public Animal(String name, String diet, String habitat) {
        this.name = name;
        this.diet = diet;
        this.habitat = habitat;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDiet() {
        return diet;
    }

    public void setDiet(String diet) {
        this.diet = diet;
    }

    public String getHabitat() {
        return habitat;
    }

    public void setHabitat(String habitat) {
        this.habitat = habitat;
    }

        @Override
    public Animal clone() { 
        try {
            return (Animal) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }

}
