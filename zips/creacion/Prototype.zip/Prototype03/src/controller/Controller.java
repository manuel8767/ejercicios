package controller;

import model.TV;
import view.VistaConsola;

public class Controller {

    public void run() {

        VistaConsola vista=new VistaConsola();
        byte option;
        String brand="", inches="", price="";
        TV tv=new TV("Samsung", "50", "2000000");
        TV tv2;

        do { 

            option=Byte.parseByte(vista.leerTexto("\nDijita la opción que desees:\n1. Ver TV por defecto\n2. Cambiar TV por defecto\n3. Salir\n\n"));

            switch (option) {
                case 1-> {
                    vista.mostrarInformacion("\nMarca: "+tv.getBrand()+"\nPulgadas: "+tv.getInches()+"\nPrecio: "+tv.getPrice());
                    break;
                }
                case 2-> {
                    brand=vista.leerTexto("\nEscribe la marca del TV: ");
                    inches=vista.leerTexto("Dijita el número de pulgadas del TV: ");
                    price=vista.leerTexto("Escribe el precio del TV: ");
                    tv2=new TV(brand, inches, price);
                    tv=tv2;
                    break;
                }
                case 3-> {
                    break;
                }
            }
        } while (option!=3);
        System.exit(0);

    }

}
