package model;

public class TV { 

    private String brand;
    private String inches;
    private String price;

    public TV(String brand, String inches, String price) {
        this.brand = brand;
        this.inches = inches;
        this.price = price;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getInches() {
        return inches;
    }

    public void setInches(String inches) {
        this.inches = inches;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

}
