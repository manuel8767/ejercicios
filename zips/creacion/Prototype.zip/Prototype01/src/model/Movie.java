package model;

public class Movie implements Cloneable {

    private String name;
    private String director;
    private String genre;

    public Movie(String name, String director, String genre) {
        this.name = name;
        this.director = director;
        this.genre = genre;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    @Override
    public Movie clone() {
        try {
            return (Movie) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }

}
