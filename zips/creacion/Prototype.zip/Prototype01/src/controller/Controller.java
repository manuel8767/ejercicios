package controller;

import model.Movie;
import view.VistaConsola;

public class Controller {

    public void run() {

        VistaConsola vista=new VistaConsola();
        byte option;
        String name="Avengers Endgame", director="Anthony Russo, Joe Russo", genre="Action/Sci-fi";
        Movie movie=new Movie(name, director, genre);

        do { 

            option=Byte.parseByte(vista.leerTexto("\nDijita la opción que desees:\n1. Ver película por defecto\n2. Cambiar película por defecto\n3. Salir\n\n"));

            switch (option) {
                case 1-> {
                    vista.mostrarInformacion("\nNombre: "+name+"\nDirector: "+director+"\nGénero: "+genre);
                    break;
                }
                case 2-> {
                    name=vista.leerTexto("\nEscribe el nombre de la nueva película: ");
                    director=vista.leerTexto("Escribe el nombre del director de la nueva película: ");
                    genre=vista.leerTexto("Escribe el genéro de la nueva película: ");
                    movie.clone();
                    movie.setName(name);
                    movie.setDirector(director);
                    movie.setGenre(genre);
                    break;
                }
                case 3-> {
                    break;
                }
            }
        } while (option!=3);
        System.exit(0);

    }

}
