package controller;

import model.Builder;
import view.VistaConsola;

public class Controller {

    public void run() {

        VistaConsola vista=new VistaConsola();
        String screen;
        String speakers;
        String mouse;
        String keyboard;
        String chasis;
        String ram;
        String mboard;
        String processor;
        String gcard;
        String power;
        String ssd;

        vista.mostrarInformacion("Dijita el nombre de todos los componentes de tu PC:");
        screen=vista.leerTexto("¿Qué pantalla tienes? ");
        speakers=vista.leerTexto("¿Qué parlantes tienes? ");
        mouse=vista.leerTexto("¿Qué mouse tienes? ");
        keyboard=vista.leerTexto("¿Qué teclado tienes? ");
        chasis=vista.leerTexto("¿Qué chasis tienes? ");
        ram=vista.leerTexto("¿Qué RAM tienes? ");
        mboard=vista.leerTexto("¿Qué placa madre tienes? ");
        processor=vista.leerTexto("¿Qué procesador tienes? ");
        gcard=vista.leerTexto("¿Qué tarjeta gráfica tienes? ");
        power=vista.leerTexto("¿Qué fuente de poder tienes? ");
        ssd=vista.leerTexto("¿Qué SSD tienes? ");

        new Builder().screen(screen).speakers(speakers).mouse(mouse).keyboard(keyboard).chasis(chasis).ram(ram).mboard(mboard).processor(processor).gcard(gcard).power(power).ssd(ssd).build();

        vista.mostrarInformacion("\nDatos:\nChasis: "+chasis+"\nFuente de Poder: "+power+"\nPlaca Madre: "+mboard+"\nProcesador: "+processor+"\nSSD: "+ssd+"\nRAM: "+ram+"\nTarjeta Gráfica: "+gcard+
        "\nPantalla: "+screen+"\nTeclado: "+keyboard+"\nMouse: "+mouse+"\nParlantes: "+speakers);

    }

}
