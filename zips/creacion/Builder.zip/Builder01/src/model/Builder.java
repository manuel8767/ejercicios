package model;

public class Builder {

    private PC pc;

    public Builder() {
        this.pc=new PC();
    }

    public Builder screen(String screen) {
        this.pc.setScreen(screen);
        return this;
    }

    public Builder speakers(String speakers) {
        this.pc.setSpeakers(speakers);
        return this;
    }

    public Builder mouse(String mouse) {
        this.pc.setMouse(mouse);
        return this;
    }

    public Builder keyboard(String keyboard) {
        this.pc.setKeyboard(keyboard);
        return this;
    }

    public Builder chasis(String chasis) {
        this.pc.setChasis(chasis);
        return this;
    }

    public Builder ram(String ram) {
        this.pc.setRam(ram);
        return this;
    }

    public Builder power(String power) {
        this.pc.setPower(power);
        return this;
    }

    public Builder processor(String processor) {
        this.pc.setProcessor(processor);
        return this;
    }

    public Builder gcard(String gcard) {
        this.pc.setGcard(gcard);
        return this;
    }

    public Builder mboard(String mboard) {
        this.pc.setMboard(mboard);
        return this;
    }

    public Builder ssd(String ssd) {
        this.pc.setSsd(ssd);
        return this;
    }

    public PC build() {
        return this.pc;
    }

}
