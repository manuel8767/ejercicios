package model1;

public class Builder {

    private User user;

    public Builder() {
        this.user=new User();
    }

    public Builder name(String name) {
        this.user.setName(name);
        return this;
    }

    public Builder lastname(String lastname) {
        this.user.setLastname(lastname);
        return this;
    }

    public Builder email(String email) {
        this.user.setEmail(email);
        return this;
    }

    public Builder bloodtype(String bloodtype) {
        this.user.setBloodtype(bloodtype);
        return this;
    }

    public Builder id(long id) {
        this.user.setId(id);
        return this;
    }

    public Builder phone(long phone) {
        this.user.setPhone(phone);
        return this;
    }

    public User build() {
        return this.user;
    }

}
