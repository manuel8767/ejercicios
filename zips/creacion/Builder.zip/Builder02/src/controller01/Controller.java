package controller01;

import model1.Builder;
import view1.VistaConsola;

public class Controller {

    public void run() {

        VistaConsola vista=new VistaConsola();
        long id;
        String name;
        String lastname;
        String email;
        String bloodtype;
        long phone;

        id=vista.leerDatoLong("Ingresa tu ID: ");
        name=vista.leerTexto("Ingresa tu nombre: ");
        lastname=vista.leerTexto("Ingresa tu apellido: ");
        email=vista.leerTexto("Ingresa tu Email: ");
        bloodtype=vista.leerTexto("Ingresa tu tipo de sangre: ");
        phone=vista.leerDatoLong("Ingresa tu número de teléfono: ");

        new Builder().name(name).id(id).bloodtype(bloodtype).lastname(lastname).email(email).phone(phone).build();
        vista.mostrarInformacion("\nDatos:\nID: "+id+"\nNombre: "+name+"\nApellido: "+lastname+"\nCorreo: "+email+"\nTeléfono: "+phone+"\nTipo de sangre: "+bloodtype);

    }

}
