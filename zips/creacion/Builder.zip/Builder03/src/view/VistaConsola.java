package view;

import java.util.Scanner;

public class VistaConsola {

	private Scanner sc;

	public VistaConsola() {
		sc = new Scanner(System.in);
	}

	public void mostrarInformacion(String mensaje, boolean maybe) {
		System.out.print(mensaje+": ");
		System.out.println(maybe);
	}

	public boolean leerBoolean(String mensaje) {
		String info;
		boolean type=false;
		System.out.print(mensaje);
		info=sc.nextLine();
		if (info.equalsIgnoreCase("Si")) {
			type=true;
		}
		return type;
	}

}
