package controller;

import model.Builder;
import view.VistaConsola;

public class Controller {

    public void run () {

        VistaConsola vista=new VistaConsola();
        boolean icecream;
        boolean apple;
        boolean cheese;
        boolean mango;
        boolean banana;
        boolean kiwi;
        boolean pear;

        icecream=vista.leerBoolean("¿Quieres helado (Si o No)? ");
        apple=vista.leerBoolean("¿Quieres manzana (Si o No)? ");
        cheese=vista.leerBoolean("¿Quieres queso (Si o No)? ");
        mango=vista.leerBoolean("¿Quieres mango (Si o No)? ");
        banana=vista.leerBoolean("¿Quieres banano (Si o No)? ");
        kiwi=vista.leerBoolean("¿Quieres kiwi (Si o No)? ");
        pear=vista.leerBoolean("¿Quieres pera (Si o No)? ");

        new Builder().apple(apple).banana(banana).cheese(cheese).iceCream(icecream).kiwi(kiwi).mango(mango).pear(pear).build();
        vista.mostrarInformacion("\nHelado",icecream);
        vista.mostrarInformacion("Manzana",apple);
        vista.mostrarInformacion("Queso",cheese);
        vista.mostrarInformacion("Mango",mango);
        vista.mostrarInformacion("Banano",banana);
        vista.mostrarInformacion("Kiwi",kiwi);
        vista.mostrarInformacion("Pera",pear);
    }

}
