package model;

public class FruitSalad {

    private boolean icecream;
    private boolean apple;
    private boolean cheese;
    private boolean mango;
    private boolean banana;
    private boolean kiwi;
    private boolean pear;

    public boolean isIcecream() {
        return icecream;
    }

    public void setIcecream(boolean icecream) {
        this.icecream = icecream;
    }

    public boolean isApple() {
        return apple;
    }

    public void setApple(boolean apple) {
        this.apple = apple;
    }

    public boolean isCheese() {
        return cheese;
    }

    public void setCheese(boolean cheese) {
        this.cheese = cheese;
    }

    public boolean isMango() {
        return mango;
    }

    public void setMango(boolean mango) {
        this.mango = mango;
    }

    public boolean isBanana() {
        return banana;
    }

    public void setBanana(boolean banana) {
        this.banana = banana;
    }

    public boolean isKiwi() {
        return kiwi;
    }

    public void setKiwi(boolean kiwi) {
        this.kiwi = kiwi;
    }

    public boolean isPear() {
        return pear;
    }

    public void setPear(boolean pear) {
        this.pear = pear;
    } 

}
