package model;

public class Builder {

    private FruitSalad salad;

    public Builder() {
        this.salad=new FruitSalad();
    }

    public Builder iceCream(boolean icecream) {
        this.salad.setIcecream(icecream);
        return this;
    }

    public Builder apple(boolean apple) {
        this.salad.setApple(apple);
        return this;
    }

    public Builder cheese(boolean cheese) {
        this.salad.setCheese(cheese);
        return this;
    }

    public Builder mango(boolean mango) {
        this.salad.setMango(mango);
        return this;
    }

    public Builder banana(boolean banana) {
        this.salad.setBanana(banana);
        return this;
    }

    public Builder kiwi(boolean kiwi) {
        this.salad.setKiwi(kiwi);
        return this;
    }

    public Builder pear(boolean pear) {
        this.salad.setPear(pear);
        return this;
    }

    public FruitSalad build() {
        return this.salad;
    }
}
