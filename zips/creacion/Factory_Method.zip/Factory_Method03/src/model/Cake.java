package model;

import model.abstracto.Bakery;

public class Cake extends Bakery{

    public Cake(int option) {
        super(option);
    }

    @Override
    public String prepare() {
        return "Pastel en camino...";
    }

}
