package model.abstracto;

public abstract class Bakery {

    protected int option;

    public Bakery(int option) {
        this.option=option;
    }

    public abstract String prepare();

}
