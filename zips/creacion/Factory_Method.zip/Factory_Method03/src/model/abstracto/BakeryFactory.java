package model.abstracto;

public interface BakeryFactory {

    Bakery create(int option);

}
