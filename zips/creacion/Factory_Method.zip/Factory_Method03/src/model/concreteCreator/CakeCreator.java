package model.concreteCreator;

import model.Cake;
import model.abstracto.Bakery;
import model.abstracto.BakeryFactory;

public class CakeCreator implements BakeryFactory{

    @Override
    public Bakery create(int option) {
        return new Cake(option);
    }

}
