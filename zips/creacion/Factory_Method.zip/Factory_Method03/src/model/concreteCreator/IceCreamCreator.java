package model.concreteCreator;

import model.IceCream;
import model.abstracto.Bakery;
import model.abstracto.BakeryFactory;

public class IceCreamCreator implements BakeryFactory{

    @Override
    public Bakery create(int option) {
        return new IceCream(option);
    }

}
