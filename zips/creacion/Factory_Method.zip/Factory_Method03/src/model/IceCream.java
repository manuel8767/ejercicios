package model;

import model.abstracto.Bakery;

public class IceCream extends Bakery{

    public IceCream(int option) {
        super(option);
    }

    @Override
    public String prepare() {
        return "Helado en camino...";
    }

}
