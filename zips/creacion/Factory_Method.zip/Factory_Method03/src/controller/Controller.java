package controller;

import model.abstracto.Bakery;
import model.abstracto.BakeryFactory;
import model.concreteCreator.CakeCreator;
import model.concreteCreator.IceCreamCreator;
import view.VistaConsola;

public class Controller {

    public void run() {

        VistaConsola vista=new VistaConsola();
        int option;
        BakeryFactory fabric;
        Bakery bakery;

        vista.mostrarInformacion("Según la pregunta dijita el número 1 o el número 0.");
        option=vista.leerDatoEntero("¿Quieres un pastel(1) o un helado(0)? ");


        if (option==1) {
            fabric=new CakeCreator();
            bakery=fabric.create(option);
            vista.mostrarInformacion(bakery.prepare());
        }
        if (option==0) {
            fabric=new IceCreamCreator();
            bakery=fabric.create(option);
            vista.mostrarInformacion(bakery.prepare());
        }

    }

}
