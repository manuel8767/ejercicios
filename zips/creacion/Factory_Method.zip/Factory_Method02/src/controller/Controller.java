package controller;

import model.abstracto.Message;
import model.abstracto.MessageFactory;
import model.concreteCreator.EmailCreator;
import model.concreteCreator.SMSCreator;
import view.VistaConsola;

public class Controller {

    public void run() {

        VistaConsola vista=new VistaConsola();
        String way;
        MessageFactory fabric;
        Message message=null;

        way=vista.leerTexto("¿Qué medio vas a usar para enviar tu mensaje, (SMS) o (Email)? ");

        if (way.equalsIgnoreCase("SMS")) {
            fabric=new SMSCreator();
            message=fabric.create(way);
        }
        if (way.equalsIgnoreCase("Email")) {
            fabric=new EmailCreator();
            message=fabric.create(way);
        }

        vista.mostrarInformacion(message.send());

    }

}
