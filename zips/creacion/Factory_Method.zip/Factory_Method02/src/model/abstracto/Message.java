package model.abstracto;

public abstract class Message {

    protected String way;

    public Message(String way) {
        this.way=way;
    }

    public abstract String send();

}
