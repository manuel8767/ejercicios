package model.abstracto;

public interface MessageFactory {

    Message create(String way);

}
