package model;

import model.abstracto.Message;
import view.VistaConsola;

public class SMS extends Message {

    public SMS(String way) {
        super(way);
    }

    @Override
    public String send() {
        VistaConsola view=new VistaConsola();
        String info;
        info=view.leerTexto("¿Qué mensaje deseas enviar? ");
        return "Enviaste: "+info;
    }

}
