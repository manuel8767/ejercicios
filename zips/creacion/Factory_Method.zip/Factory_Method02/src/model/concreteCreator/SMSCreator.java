package model.concreteCreator;

import model.SMS;
import model.abstracto.Message;
import model.abstracto.MessageFactory;

public class SMSCreator implements MessageFactory{

    @Override
    public Message create(String way) {
        return new SMS(way);
    }

}
