package model.concreteCreator;

import model.Email;
import model.abstracto.Message;
import model.abstracto.MessageFactory;

public class EmailCreator implements MessageFactory{

    @Override
    public Message create(String way) {
        return new Email(way);
    }

}
