package model.concreteCreator;

import model.Skate;
import model.abstracto.Vehicle;
import model.abstracto.VehicleFactory;

public class SkateCreator implements VehicleFactory{

    @Override
    public Vehicle create() {
        return new Skate();
    }

}
