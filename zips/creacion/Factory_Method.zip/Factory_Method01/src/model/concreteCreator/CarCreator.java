package model.concreteCreator;

import model.Car;
import model.abstracto.Vehicle;
import model.abstracto.VehicleFactory;

public class CarCreator implements VehicleFactory{

    @Override
    public Vehicle create() {
        return new Car();
    }

}
