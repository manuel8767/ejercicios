package model.concreteCreator;

import model.Airplane;
import model.abstracto.Vehicle;
import model.abstracto.VehicleFactory;

public class AirplaneCreator implements VehicleFactory{

    @Override
    public Vehicle create() {
        return new Airplane();
    }

}
