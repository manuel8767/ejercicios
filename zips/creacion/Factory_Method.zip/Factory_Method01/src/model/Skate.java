package model;

import model.abstracto.Vehicle;

public class Skate extends Vehicle{

    @Override
    public String describe() {
        return "Skate en camino...";
    }

}
