package model.abstracto;

public interface VehicleFactory {

    Vehicle create();

}
