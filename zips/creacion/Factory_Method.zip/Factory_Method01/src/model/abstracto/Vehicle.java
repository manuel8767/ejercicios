package model.abstracto;

public abstract class Vehicle {

    public abstract String describe();

}
