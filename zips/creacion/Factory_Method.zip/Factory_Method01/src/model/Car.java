package model;

import model.abstracto.Vehicle;

public class Car extends Vehicle {

    @Override
    public String describe() {
        return "Carro en camino...";
    }

}
