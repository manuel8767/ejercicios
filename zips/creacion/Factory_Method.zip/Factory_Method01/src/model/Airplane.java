package model;

import model.abstracto.Vehicle;

public class Airplane extends Vehicle{

    @Override
    public String describe() {
        return "Avión en camino...";
    }

}
