package controller;

import model.abstracto.Vehicle;
import model.abstracto.VehicleFactory;
import model.concreteCreator.AirplaneCreator;
import model.concreteCreator.CarCreator;
import model.concreteCreator.SkateCreator;
import view.VistaConsola;

public class Controller {

    public void run() {

        VistaConsola vista=new VistaConsola();
        String type, rta="Opción inválida.";
        VehicleFactory fabric;
        Vehicle vehicle;

        type=vista.leerTexto("¿Qué vehículo quieres (Avión, carro o skate)? ");

        if (type.equalsIgnoreCase("Avión")) {
            fabric=new AirplaneCreator();
            vehicle=fabric.create();
            rta=vehicle.describe();
        }
        if (type.equalsIgnoreCase("Carro")) {
            fabric=new CarCreator();
            vehicle=fabric.create();
            rta=vehicle.describe();
        }
        if (type.equalsIgnoreCase("Skate")) {
            fabric=new SkateCreator();
            vehicle=fabric.create();
            rta=vehicle.describe();
        }

        vista.mostrarInformacion(rta);

    }

}
