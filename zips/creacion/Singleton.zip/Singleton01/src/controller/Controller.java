package controller;

import model.President;
import view.VistaConsola;

public class Controller {

	private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
	}

    public void run() {

        String name;

        name=vista.leerTexto("Dijita el nombre del nuevo presidente: ");

        President president=President.getInstance();
        president.establish(name);
        vista.mostrarInformacion("Bienvenido Sr. "+name);

    }

}
