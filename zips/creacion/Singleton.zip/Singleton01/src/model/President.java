package model;

public class President {

    private static President object=null;

    private President() {
        
    }

    public static President getInstance() {
        if (object==null) {
            object=new President();
        }
        return object;
    }

    public String establish(String name) {
        return name;
    }

}
