package model;

public class TrafficLight {

    private static TrafficLight object=null;

    private TrafficLight() {

    }

    public static TrafficLight getInstance() {
        if (object==null) {
            object=new TrafficLight();
        }
        return object;
    }

    public String use() {
        return "Green...\nYellow...\nRed...";
    }

}
