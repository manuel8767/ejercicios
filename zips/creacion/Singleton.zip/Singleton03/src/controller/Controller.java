package controller;

import model.TrafficLight;
import view.VistaConsola;

public class Controller {

    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
	}

    public void run() {

        TrafficLight light=TrafficLight.getInstance();
        vista.mostrarInformacion(light.use());

    }

}
