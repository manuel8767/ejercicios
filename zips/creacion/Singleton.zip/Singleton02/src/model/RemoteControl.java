package model;

public class RemoteControl {

    private static RemoteControl object=null;

    private RemoteControl() {

    }

    public static RemoteControl getInstance() {
        if (object==null) {
            object=new RemoteControl();
        }
        return object;
    }

    public String establish() {
        return "Solo tienes disponible este control para encender la TV.";
    }

}
