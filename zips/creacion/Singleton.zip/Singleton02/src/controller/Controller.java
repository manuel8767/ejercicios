package controller;

import model.RemoteControl;
import view.VistaConsola;

public class Controller {

	private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
	}

    public void run() {
        RemoteControl control=RemoteControl.getInstance();
        vista.mostrarInformacion(control.establish());
    }

}
