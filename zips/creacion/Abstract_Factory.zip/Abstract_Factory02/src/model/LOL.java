package model;

import model.abstracto.StrategyGames;

public class LOL extends StrategyGames {

    @Override
    public String open() {
        return "Abriendo League of Legends...";
    }

}
