package model;

import model.abstracto.ShooterGames;

public class MW3 extends ShooterGames {

    @Override
    public String open() {
        return "Abriendo Call od Duty Modern Warfare 3...";
    }

}
