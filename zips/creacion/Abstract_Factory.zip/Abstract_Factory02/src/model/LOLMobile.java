package model;

import model.abstracto.StrategyGames;

public class LOLMobile extends StrategyGames {

    @Override
    public String open() {
        return "Abriendo League of Legends Mobile...";
    }

}
