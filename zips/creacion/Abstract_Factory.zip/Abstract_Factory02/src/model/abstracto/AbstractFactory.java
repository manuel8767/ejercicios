package model.abstracto;

public interface AbstractFactory {

    ShooterGames createShooter();
    StrategyGames createStrategy();

}
