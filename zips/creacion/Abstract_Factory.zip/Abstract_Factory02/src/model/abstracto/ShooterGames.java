package model.abstracto;

public abstract class ShooterGames {

    public abstract String open();

}
