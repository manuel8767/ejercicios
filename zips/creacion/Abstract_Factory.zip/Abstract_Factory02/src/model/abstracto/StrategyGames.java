package model.abstracto;

public abstract class StrategyGames {

    public abstract String open();

}
