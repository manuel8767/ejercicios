package model;

import model.abstracto.ShooterGames;

public class CODMobile extends ShooterGames {

    @Override
    public String open() {
        return "Abriendo Call of Duty Mobile...";
    }

}
