package model.concreteCreator;

import model.CODMobile;
import model.LOLMobile;
import model.abstracto.AbstractFactory;
import model.abstracto.ShooterGames;
import model.abstracto.StrategyGames;

public class PhoneGamesFactory implements AbstractFactory {

    @Override
    public ShooterGames createShooter() {
        return new CODMobile();
    }

    @Override
    public StrategyGames createStrategy() {
        return new LOLMobile();
    }


}
