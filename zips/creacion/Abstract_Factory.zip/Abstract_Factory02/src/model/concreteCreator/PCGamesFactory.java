package model.concreteCreator;

import model.LOL;
import model.MW3;
import model.abstracto.AbstractFactory;
import model.abstracto.ShooterGames;
import model.abstracto.StrategyGames;

public class PCGamesFactory implements AbstractFactory {

    @Override
    public ShooterGames createShooter() {
        return new MW3();
    }

    @Override
    public StrategyGames createStrategy() {
        return new LOL();
    }

}
