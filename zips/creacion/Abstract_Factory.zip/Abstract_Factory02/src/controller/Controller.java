package controller;

import model.abstracto.AbstractFactory;
import model.abstracto.ShooterGames;
import model.abstracto.StrategyGames;
import model.concreteCreator.PCGamesFactory;
import model.concreteCreator.PhoneGamesFactory;
import view.VistaConsola;

public class Controller {

    private VistaConsola vista;
    private AbstractFactory fabric;
    private ShooterGames shooter;
    private StrategyGames strategy;

    public Controller () {
        vista=new VistaConsola();
    }

    public void run() {

        byte option;

        do { 

            option=Byte.parseByte(vista.leerTexto("\nDijita la opción que quieras:\n1. Jugar en PC\n2. Jugar en celular\n3. Salir\n\n"));

            switch (option) {
                case 1-> {
                    pc();
                    break;
                }
                case 2-> {
                    celular();
                    break;
                }
                case 3-> {
                    vista.mostrarInformacion("\nGracias por tu visita.");
                    break;
                }
            }
        } while (option!=3);
        System.exit(0);

    }

    public void pc() {

        byte opcion;

        do {

            opcion=Byte.parseByte(vista.leerTexto("\nDijita el tipo de juego que quieras jugar:\n1. Shooter\n2. Estrategia\n3. Salir\n\n"));

            switch (opcion) {
                case 1-> {
                    fabric=new PCGamesFactory();
                    shooter=fabric.createShooter();
                    vista.mostrarInformacion("\n"+shooter.open());
                    run();
                    break;
                }
                case 2-> {
                    fabric=new PCGamesFactory();
                    strategy=fabric.createStrategy();
                    vista.mostrarInformacion("\n"+strategy.open());
                    run();
                    break;
                }
                case 3-> {
                    run();
                    break;
                }
            }
        } while (opcion!=3);
        System.exit(0);

    }

    public void celular() {

        byte optionn;

        do {

            optionn=Byte.parseByte(vista.leerTexto("\nDijita el tipo de juego que quieres jugar:\n1. Shooter\n2. Estrategia\n3. Salir\n\n"));

            switch (optionn) {
                case 1-> {
                    fabric=new PhoneGamesFactory();
                    shooter=fabric.createShooter();
                    vista.mostrarInformacion("\n"+shooter.open());
                    run();
                    break;
                }
                case 2-> {
                    fabric=new PhoneGamesFactory();
                    strategy=fabric.createStrategy();
                    vista.mostrarInformacion("\n"+strategy.open());
                    run();
                    break;
                }
                case 3-> {
                    run();
                    break;
                }
            }
        } while (optionn!=3);
        System.exit(0);

    }

}