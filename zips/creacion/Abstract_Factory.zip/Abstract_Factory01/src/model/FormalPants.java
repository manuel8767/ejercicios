package model;

import model.abstracto.Pants;

public class FormalPants extends Pants{

    @Override
    public String buy() {
        return "Pantalones formales en camino...";
    }

}
