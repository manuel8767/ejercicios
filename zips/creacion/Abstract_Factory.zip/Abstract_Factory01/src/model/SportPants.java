package model;

import model.abstracto.Pants;

public class SportPants extends Pants{

    @Override
    public String buy() {
        return "Pantalones deportivos en camino...";
    }

}
