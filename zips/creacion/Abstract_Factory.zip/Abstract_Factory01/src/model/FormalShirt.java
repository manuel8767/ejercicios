package model;

import model.abstracto.Shirt;

public class FormalShirt extends Shirt{

    @Override
    public String buy() {
        return "Camisa formal en camino...";
    }

}
