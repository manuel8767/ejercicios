package model.concreteCreator;

import model.FormalPants;
import model.FormalShirt;
import model.abstracto.AbstractFactory;
import model.abstracto.Pants;
import model.abstracto.Shirt;

public class FormalFactory implements AbstractFactory{

    @Override
    public Pants createPants() {
        return new FormalPants();
    }

    @Override
    public Shirt createShirt() {
        return new FormalShirt();
    }

}
