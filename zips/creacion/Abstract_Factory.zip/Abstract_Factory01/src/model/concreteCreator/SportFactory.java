package model.concreteCreator;

import model.SportPants;
import model.SportShirt;
import model.abstracto.AbstractFactory;
import model.abstracto.Pants;
import model.abstracto.Shirt;

public class SportFactory implements AbstractFactory{

    @Override
    public Pants createPants() {
        return new SportPants();
    }

    @Override
    public Shirt createShirt() {
        return new SportShirt();
    }

}
