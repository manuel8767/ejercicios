package model.abstracto;

public abstract class Pants {

    public abstract String buy();

}
