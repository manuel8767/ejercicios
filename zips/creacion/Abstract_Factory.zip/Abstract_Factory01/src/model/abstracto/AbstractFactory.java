package model.abstracto;

public interface AbstractFactory {

    Pants createPants();
    Shirt createShirt();

}
