package model.abstracto;

public abstract class Shirt {

    public abstract String buy();

}
