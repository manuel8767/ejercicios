package controller;

import model.abstracto.AbstractFactory;
import model.abstracto.Pants;
import model.abstracto.Shirt;
import model.concreteCreator.FormalFactory;
import model.concreteCreator.SportFactory;
import view.VistaConsola;

public class Controller {

    public void run() {

        VistaConsola vista=new VistaConsola();
        String item, material;
        AbstractFactory fabric;
        Shirt shirt;
        Pants pants;

        item=vista.leerTexto("¿Qué prenda quieres, una camisa o un pantalón? ");
        material=vista.leerTexto("¿Quieres que sea formal o sport? ");

        if (item.equalsIgnoreCase("Camisa") && material.equalsIgnoreCase("Formal")) {
            fabric=new FormalFactory();
            shirt=fabric.createShirt();
            vista.mostrarInformacion(shirt.buy());
        }
        if (item.equalsIgnoreCase("Camisa") && material.equalsIgnoreCase("Sport")) {
            fabric=new SportFactory();
            shirt=fabric.createShirt();
            vista.mostrarInformacion(shirt.buy());
        }
        if (item.equalsIgnoreCase("Pantalon") && material.equalsIgnoreCase("Formal")) {
            fabric=new FormalFactory();
            pants=fabric.createPants();
            vista.mostrarInformacion(pants.buy());
        }
        if (item.equalsIgnoreCase("Pantalon") && material.equalsIgnoreCase("Sport")) {
            fabric=new SportFactory();
            pants=fabric.createPants();
            vista.mostrarInformacion(pants.buy());
        }

    }

}