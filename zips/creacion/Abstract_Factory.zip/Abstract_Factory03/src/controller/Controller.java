package controller;

import model.abstracto.AbstractFactory;
import model.abstracto.House;
import model.abstracto.World;
import model.concreteCreator.FuturisticFactory;
import model.concreteCreator.MedievalFactory;
import view.VistaConsola;

public class Controller {

    public void run() {

        VistaConsola vista=new VistaConsola();
        AbstractFactory fabric;
        World world;
        House house;
        byte option;
        String yesorno;

        do { 

            option=Byte.parseByte(vista.leerTexto("\nDijita el número del mundo donde quieres jugar:\n1. Medieval\n2. Futurista\n3. Salir\n\n"));

            switch (option) {
                case 1-> {
                    fabric=new MedievalFactory();
                    world=fabric.create();
                    vista.mostrarInformacion(world.play());
                    yesorno=vista.leerTexto("\n¿Quieres construir una casa (Si o No)? ");
                    if (yesorno.equalsIgnoreCase("Si")) {
                        house=fabric.creating();
                        vista.mostrarInformacion(house.build());
                    }
                    break;
                }
                case 2-> {
                    fabric=new FuturisticFactory();
                    world=fabric.create();
                    vista.mostrarInformacion(world.play());
                    yesorno=vista.leerTexto("\n¿Quieres construir una casa (Si o No)? ");
                    if (yesorno.equalsIgnoreCase("Si")) {
                        house=fabric.creating();
                        vista.mostrarInformacion(house.build());
                    }
                    break;
                }
                case 3-> {
                    vista.mostrarInformacion("\nGracias por tu visita.");
                    break;
                }
            }
        } while (option!=3);
        System.exit(0);
    }

}
