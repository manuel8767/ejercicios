package model.concreteCreator;

import model.Hijacked;
import model.New;
import model.abstracto.AbstractFactory;
import model.abstracto.House;
import model.abstracto.World;

public class FuturisticFactory implements AbstractFactory {

    @Override
    public World create() {
        return new Hijacked();
    }

    @Override
    public House creating() {
        return new New();
    }


}
