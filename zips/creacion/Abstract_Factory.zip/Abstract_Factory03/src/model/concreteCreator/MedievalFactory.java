package model.concreteCreator;

import model.Antique;
import model.Crash;
import model.abstracto.AbstractFactory;
import model.abstracto.House;
import model.abstracto.World;

public class MedievalFactory implements AbstractFactory {

    @Override
    public World create() {
        return new Crash();
    }

    @Override
    public House creating() {
        return new Antique();
    }



}
