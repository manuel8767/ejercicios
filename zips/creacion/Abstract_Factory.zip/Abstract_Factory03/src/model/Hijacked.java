package model;

import model.abstracto.World;

public class Hijacked extends World {

    @Override
    public String play() {
        return "\nMapa Hijacked seleccionado...";
    }


}
