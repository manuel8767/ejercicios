package model;

import model.abstracto.World;

public class Crash extends World {

    @Override
    public String play() {
        return "\nMapa Crash seleccionado...";
    }



}
