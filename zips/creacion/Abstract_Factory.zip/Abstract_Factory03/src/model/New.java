package model;

import model.abstracto.House;

public class New extends House {

    @Override
    public String build() {
        return "\nCasa futurista construida...";
    }

}
