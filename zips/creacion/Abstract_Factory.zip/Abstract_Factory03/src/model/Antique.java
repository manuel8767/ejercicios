package model;

import model.abstracto.House;

public class Antique extends House {

    @Override
    public String build() {
        return "\nCasa medieval construida...";
    }

}
