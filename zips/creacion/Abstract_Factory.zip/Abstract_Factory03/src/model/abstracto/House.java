package model.abstracto;

public abstract class House {

    public abstract String build();

}
