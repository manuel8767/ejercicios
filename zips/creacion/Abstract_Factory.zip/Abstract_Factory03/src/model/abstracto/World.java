package model.abstracto;

public abstract class World {

    public abstract String play();

}
