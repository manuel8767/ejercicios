package model.abstracto;

public interface AbstractFactory {

    World create();
    House creating();

}
