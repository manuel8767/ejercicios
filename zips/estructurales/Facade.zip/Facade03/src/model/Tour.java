package model;

import view.VistaConsola;

public class Tour {

    private VistaConsola vista;

    public Tour() {
        vista=new VistaConsola();
    }

    void bookingTour(String city) { vista.mostrarInformacion("Buscando tours en "+city+"..."); }

}
