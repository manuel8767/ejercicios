package model;

public class Facade {

    private Flight flight;
    private Hotel hotel;
    private Tour tour;

    public Facade() {
        flight=new Flight();
        hotel=new Hotel();
        tour=new Tour();
    }

    public void nextHoliday(String origin, String destination) {
        flight.bookingflight(origin, destination);
        hotel.bookingHotel(destination);
        tour.bookingTour(destination);
    }

}
