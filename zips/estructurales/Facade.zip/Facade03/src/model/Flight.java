package model;

import view.VistaConsola;

public class Flight {

    private VistaConsola vista;

    public Flight() {
        vista=new VistaConsola();
    }

    void bookingflight(String origin, String destination) { vista.mostrarInformacion("Buscando vuelos desde "+origin+" hasta "+destination+"..."); }

}
