package model;

import view.VistaConsola;

public class Hotel {

    private VistaConsola vista;

    public Hotel() {
        vista=new VistaConsola();
    }

    void bookingHotel(String city) { vista.mostrarInformacion("Buscando hoteles en "+city+"..."); }

}
