package controller;

import model.Facade;
import view.VistaConsola;

public class Controller {

    public void run() {

        VistaConsola vista;
        Facade facade;
        String origin;
        String destination;

        vista=new VistaConsola();
        facade=new Facade();

        origin=vista.leerTexto("¿Cuál es el país desde dónde vas a partir? ");
        destination=vista.leerTexto("¿Cuál es el país a dónde quieres llegar? ");
        facade.nextHoliday(origin, destination);
    }

}
