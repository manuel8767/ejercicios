package controller;

import model.Facade;
import view.VistaConsola;

public class Controller {

    public void run() {

        VistaConsola vista;
        Facade facade;
        String option;

        vista=new VistaConsola();
        facade=new Facade();

        option=vista.leerTexto("¿Quieres activar el sistema de seguridad (Si o No)? ");
        if (option.equalsIgnoreCase("Si")) {
            facade.activateSecuritySystem();
        }
        else {
            facade.deactivateSecuritySystem();
        }
    }

}
