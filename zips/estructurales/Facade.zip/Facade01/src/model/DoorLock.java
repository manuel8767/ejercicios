package model;

public class DoorLock {

    String close() { return "Puerta cerrada"; }
    String open() { return "Puerta abierta"; }

}
