package model;

public class Facade {

    private Alarm alarm;
    private Camera camera;
    private DoorLock doorlock;

    public Facade() {
        alarm=new Alarm();
        camera=new Camera();
        doorlock=new DoorLock();
    }

    public void activateSecuritySystem() {
        alarm.activate();
        camera.turnOn();
        doorlock.close();
    }

    public void deactivateSecuritySystem() {
        alarm.deactivate();
        camera.turnOff();
        doorlock.open();
    }

}
