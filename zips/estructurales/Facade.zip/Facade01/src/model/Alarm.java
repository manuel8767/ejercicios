package model;

public class Alarm {

    String activate() { return "Alarma activada"; }
    String deactivate() { return "Alarma desactivada"; }

}
