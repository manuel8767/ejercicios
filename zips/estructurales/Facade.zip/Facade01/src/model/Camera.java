package model;

public class Camera {

    String turnOn() { return "Cámaras encendidas"; }
    String turnOff() { return "Cámaras apagadas"; }

}
