package model;

public class DVD {

    String turnOn() { return "DVD encendido"; }
    String play(String movie) { return "Reproduciendo "+movie; }

}
