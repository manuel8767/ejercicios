package model;

public class Screen {

    String down() { return "Pantalla bajada"; }

}
