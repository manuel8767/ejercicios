package model;

public class Facade {

    private DVD dvd;
    private Proyector proyector;
    private Screen screen;

    public Facade() {
        dvd=new DVD();
        proyector=new Proyector();
        screen=new Screen();
    }

    public void playMovie(String movie) {
        screen.down();
        proyector.turnOn();
        dvd.turnOn();
        dvd.play(movie);
    }

}
