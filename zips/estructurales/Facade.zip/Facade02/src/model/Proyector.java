package model;

public class Proyector {

    String turnOn() { return "Proyector encendido"; }

}
