package controller;

import model.Facade;
import view.VistaConsola;

public class Controller {

    public void run() {

        VistaConsola vista;
        Facade facade;
        String movie;

        vista=new VistaConsola();
        facade=new Facade();

        movie=vista.leerTexto("¿Que película quieres ver? ");
        facade.playMovie(movie);
    }

}
