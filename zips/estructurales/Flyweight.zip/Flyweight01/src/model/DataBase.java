package model;

import java.util.ArrayList;
import java.util.List;

public class DataBase {

    private List<Person> people=new ArrayList<>();

    public void addPerson(String wholename, String id, String age, String bloodtype, String sex) {
        Flyweight flyweight=PersonFactory.getFlyweight(age, bloodtype, sex);
        Person person=new Person(wholename, id, flyweight);
        people.add(person);
    }

    public void search() {
        for (Person persons: people) {
            persons.search();
        }
    }

}
