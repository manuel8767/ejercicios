package model;

public class Person {

    private String wholename;
    private String id;
    private Flyweight flyweight;

    public Person(String wholename, String id, Flyweight flyweight) {
        this.wholename = wholename;
        this.id = id;
        this.flyweight = flyweight;
    }

    public void search() {
        flyweight.search(wholename, id);
    }

}
