package model;

import java.util.HashMap;
import java.util.Map;

public class PersonFactory {

    private static Map<String, Flyweight> db = new HashMap<>();

    public static Flyweight getFlyweight(String age, String bloodtype, String sex) {

        String key = age + ":" + bloodtype + ":" + sex;

        if (!db.containsKey(key)) {
            db.put(key, new Flyweight(age, bloodtype, sex));
        }

        return db.get(key);

    }

}
