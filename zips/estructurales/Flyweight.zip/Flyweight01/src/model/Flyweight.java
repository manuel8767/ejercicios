package model;

public class Flyweight {

    private String age;
    private String bloodtype;
    private String sex;

    public Flyweight(String age, String bloodtype, String sex) {
        this.age = age;
        this.bloodtype = bloodtype;
        this.sex = sex;
    }

    public String getAge() {
        return age;
    }

    public String getBloodtype() {
        return bloodtype;
    }

    public String getSex() {
        return sex;
    }

    public String search(String wholename, String id) {
        return "\n"+wholename+", con C.C "+id+", tipo de sangre "+bloodtype+", del género "+sex+" y con "+age+" años de edad.";
    }

}
