package controller;

import model.DataBase;
import view.VistaConsola;

public class Controller {

    public void run () {

        DataBase db=new DataBase();
        VistaConsola vista=new VistaConsola();
        byte option;
        String wholename, id, age, bloodtype, sex;

        do { 

            option=Byte.parseByte(vista.leerTexto("\nDijita la opción que desees realizar:\n1. Registrar los datos de la persona\n2. Ver las personas registradas\n3. Salir\n\n"));

            switch (option) {
                case 1-> {
                    wholename=vista.leerTexto("\n¿Cuál es el nombre completo? ");
                    id=vista.leerTexto("¿Cuál es su C.C? ");
                    age=vista.leerTexto("¿Cuál es su edad? ");
                    bloodtype=vista.leerTexto("¿Cuál es su tipo de sangre? ");
                    sex=vista.leerTexto("Cuál es su sexo de nacimiento? ");
                    db.addPerson(wholename, id, age, bloodtype, sex);
                    break;
                }
                case 2-> {
                    db.search();
                    break;
                }
                case 3-> {
                    break;
                }
            }
        } while (option!=3);
        System.exit(0);

    }

}
