package model;

public class Flyweight {

    private String product;

    public Flyweight(String product) {
        this.product = product;
    }

    public String getProduct() {
        return product;
    }

    public String describe(String name, String logo) {
        return "\n"+name+" es una empresa de "+product+" ,con un logo caracterizado por "+logo;
    }

}
