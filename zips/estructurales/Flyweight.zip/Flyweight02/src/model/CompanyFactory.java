package model;

import java.util.HashMap;
import java.util.Map;

public class CompanyFactory {

    private static Map<String, Flyweight> company = new HashMap<>(); 

    public static Flyweight getFlyweight(String product) {

        String key = product;

        if (!company.containsKey(key)) {
            company.put(key, new Flyweight(product));
        }

        return company.get(key);

    }

}
