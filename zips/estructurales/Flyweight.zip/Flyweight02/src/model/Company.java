package model;

public class Company {

    private String name;
    private String logo;
    private Flyweight flyweight;

    public Company(String name, String logo, Flyweight flyweight) {
        this.name = name;
        this.logo = logo;
        this.flyweight = flyweight;
    }

    public void describe() {
        flyweight.describe(name, logo);
    }

}
