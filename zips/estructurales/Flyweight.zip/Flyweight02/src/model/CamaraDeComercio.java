package model;

import java.util.ArrayList;
import java.util.List;

public class CamaraDeComercio {

    private List<Company> companies=new ArrayList<>();

    public void addCompany(String name, String logo, String product) {
        Flyweight flyweight=CompanyFactory.getFlyweight(product);
        Company company=new Company(name, logo, flyweight);
        companies.add(company);
    }

    public void describe() {
        for (Company i: companies) {
            i.describe();
        }
    }

}
