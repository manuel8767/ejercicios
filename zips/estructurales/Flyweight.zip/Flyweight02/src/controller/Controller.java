package controller;

import model.CamaraDeComercio;
import view.VistaConsola;

public class Controller {

    public void run () {

        CamaraDeComercio camara=new CamaraDeComercio();
        VistaConsola vista=new VistaConsola();
        byte option;
        String name, logo, product;

        do { 

            option=Byte.parseByte(vista.leerTexto("\nDijita la opción que desees realizar:\n1. Registrar nueva empresa\n2. Ver las empresas registradas\n3. Salir\n\n"));

            switch (option) {
                case 1-> {
                    name=vista.leerTexto("\n¿Cuál es el nombre? ");
                    logo=vista.leerTexto("¿Qué elementos caracterizan el logo? ");
                    product=vista.leerTexto("Cuál es el producto que mueve la empresa? ");
                    camara.addCompany(name, logo, product);
                    break;
                }
                case 2-> {
                    camara.describe();
                    break;
                }
                case 3-> {
                    break;
                }
            }
        } while (option!=3);
        System.exit(0);

    }

}
