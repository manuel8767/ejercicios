package controller;

import model.Library;
import view.VistaConsola;

public class Controller {

    public void run () {

        Library library=new Library();
        VistaConsola vista=new VistaConsola();
        byte option;
        String name, pages, writer, editorial;

        do { 

            option=Byte.parseByte(vista.leerTexto("\nDijita la opción que desees realizar:\n1. Registrar nuevo libro\n2. Ver los libros registrados\n3. Salir\n\n"));

            switch (option) {
                case 1-> {
                    name=vista.leerTexto("\n¿Cuál es el nombre? ");
                    pages=vista.leerTexto("¿Cuántas páginas tiene? ");
                    writer=vista.leerTexto("Cuál es el autor? ");
                    editorial=vista.leerTexto("Cuál es la editorial que lo publicó? ");
                    library.addBook(name, pages, writer, editorial);
                    break;
                }
                case 2-> {
                    library.describe();
                    break;
                }
                case 3-> {
                    break;
                }
            }
        } while (option!=3);
        System.exit(0);

    }

}
