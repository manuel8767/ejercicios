package model;

import java.util.HashMap;
import java.util.Map;

public class BookFactory {

    private static Map<String, Flyweight> book = new HashMap<>(); 

    public static Flyweight getFlyweight(String pages, String writer, String editorial) {

        String key=pages+":"+writer+":"+editorial;

        if (!book.containsKey(key)) {
            book.put(key, new Flyweight(pages, writer, editorial));
        }

        return book.get(key);

    }

}
