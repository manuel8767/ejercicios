package model;

import java.util.ArrayList;
import java.util.List;

public class Library {

    private List<Book> library=new ArrayList<>();

    public void addBook(String name, String pages, String writer, String editorial) {
        Flyweight flyweight=BookFactory.getFlyweight(pages, writer, editorial);
        Book book=new Book(name, flyweight);
        library.add(book);
    }

    public void describe() {
        for (Book i: library) {
            i.describe();
        }
    }

}
