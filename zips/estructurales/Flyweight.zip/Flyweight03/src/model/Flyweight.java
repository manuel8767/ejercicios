package model;

public class Flyweight {

    private String pages;
    private String writer;
    private String editorial;

    public Flyweight(String pages, String writer, String editorial) {
        this.pages=pages;
        this.writer=writer;
        this.editorial=editorial;
    }

    public String getPages() {
        return pages;
    }

    public String getWriter() {
        return writer;
    }

    public String getEditorial() {
        return editorial;
    }

    public String describe(String name) {
        return "\n"+name+", escrito por "+writer+", publicado por "+editorial+" y con una extensión de "+pages+" páginas.";
    }

}
