package model;

public class Book {

    private String name;
    private Flyweight flyweight;

    public Book(String name, Flyweight flyweight) {
        this.name = name;
        this.flyweight = flyweight;
    }

    public void describe() {
        flyweight.describe(name);
    }

}
