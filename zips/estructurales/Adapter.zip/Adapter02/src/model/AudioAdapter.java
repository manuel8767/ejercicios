package model;

public class AudioAdapter implements AudioPlayer {
    private OldMP3Player oldPlayer;

    public AudioAdapter(OldMP3Player oldPlayer) {
        this.oldPlayer = oldPlayer;
    }

    @Override
    public void play(String fileName) {
        oldPlayer.playMp3(fileName);
    }
}