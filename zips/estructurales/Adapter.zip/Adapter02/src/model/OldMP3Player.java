package model;

public class OldMP3Player {
    public void playMp3(String fileName) {
        System.out.println("Reproduciendo archivo MP3: " + fileName);
    }
}