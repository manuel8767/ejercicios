package model;

public interface AudioPlayer {
    void play(String fileName);
}