package controller;

import model.AudioAdapter;
import model.AudioPlayer;
import model.OldMP3Player;
import view.MusicView;

public class MusicTest {
        public static void main(String[] args) {
        OldMP3Player oldPlayer = new OldMP3Player();
        AudioPlayer adapter = new AudioAdapter(oldPlayer);
        MusicController controller = new MusicController(adapter);
        MusicView view = new MusicView();

        String song = "mi_cancion.mp3";
        view.showPlaying(song);
        controller.playMusic(song);
    }
}