package controller;

import model.AudioPlayer;

public class MusicController {
    private AudioPlayer player;

    public MusicController(AudioPlayer player) {
        this.player = player;
    }

    public void playMusic(String fileName) {
        player.play(fileName);
    }
}