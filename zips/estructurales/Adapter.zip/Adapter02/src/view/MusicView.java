package view;

public class MusicView {
    public void showPlaying(String song) {
        System.out.println("Reproduciendo ahora: " + song);
    }

    public void showError(String message) {
        System.out.println("Error: " + message);
    }
}