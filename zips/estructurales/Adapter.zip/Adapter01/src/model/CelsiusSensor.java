package model;

public interface CelsiusSensor {
    double getTemperatureCelsius();
}