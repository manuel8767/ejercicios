package model;

public class OldTemperatureSensor {
    public double getTemperatureFahrenheit() {
        return 98.6;
    }
}