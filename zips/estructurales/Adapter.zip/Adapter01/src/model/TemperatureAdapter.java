package model;

public class TemperatureAdapter implements CelsiusSensor {
    private OldTemperatureSensor oldSensor;

    public TemperatureAdapter(OldTemperatureSensor oldSensor) {
        this.oldSensor = oldSensor;
    }

    @Override
    public double getTemperatureCelsius() {
        double f = oldSensor.getTemperatureFahrenheit();
        return (f - 32) * 5.0 / 9.0;
    }
}