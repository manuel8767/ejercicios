package controller;

import model.CelsiusSensor;

public class TemperatureController {
    private CelsiusSensor sensor;

    public TemperatureController(CelsiusSensor sensor) {
        this.sensor = sensor;
    }

    public double showTemperature() {
        return sensor.getTemperatureCelsius();
    }
}