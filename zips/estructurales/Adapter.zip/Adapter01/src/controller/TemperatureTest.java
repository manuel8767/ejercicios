package controller;

import model.CelsiusSensor;
import model.OldTemperatureSensor;
import model.TemperatureAdapter;

public class TemperatureTest {
   public static void main(String[] args) {
        OldTemperatureSensor oldSensor = new OldTemperatureSensor();
        CelsiusSensor adapter = new TemperatureAdapter(oldSensor);
        TemperatureController controller = new TemperatureController(adapter);

        double resultado = controller.showTemperature();
        double esperado = 37.0;
        double tolerancia = 0.1;

        if (Math.abs(resultado - esperado) <= tolerancia) {
            System.out.println("Test PASÓ. Resultado: " + resultado);
        } else {
            System.out.println("Test FALLÓ. Esperado: " + esperado + ", pero fue: " + resultado);
        }
    }
}