package view;

public class TemperatureView {
    public void display(double tempCelsius) {
        System.out.println("Temperatura: " + tempCelsius + " °C");
    }
}