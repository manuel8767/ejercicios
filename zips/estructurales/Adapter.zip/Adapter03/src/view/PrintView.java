package view;

public class PrintView {
    public void showPrintStart(String message) {
        System.out.println("Iniciando impresión de: " + message);
    }

    public void showSuccess() {
        System.out.println("Documento impreso correctamente.");
    }

    public void showError(String message) {
        System.out.println("Error al imprimir: " + message);
    }
}
