package controller;

import model.OldPrinter;
import model.Printer;
import model.PrinterAdapter;
import view.PrintView;

public class PrinterTest {
   public static void main(String[] args) {
        OldPrinter oldPrinter = new OldPrinter();
        Printer adapter = new PrinterAdapter(oldPrinter);
        PrintController controller = new PrintController(adapter);
        PrintView view = new PrintView();

        String text = "Hola Mundo en Mayúsculas";
        view.showPrintStart(text);
        controller.printDocument(text);
        view.showSuccess();
    }
}