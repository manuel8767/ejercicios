package controller;

import model.Printer;

public class PrintController {
    private Printer printer;

    public PrintController(Printer printer) {
        this.printer = printer;
    }

    public void printDocument(String content) {
        printer.print(content);
    }
}