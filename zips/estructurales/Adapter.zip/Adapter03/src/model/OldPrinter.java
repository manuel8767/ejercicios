package model;

public class OldPrinter {
    public void printUppercase(String text) {
        System.out.println(text.toUpperCase());
    }
}