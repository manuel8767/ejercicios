package model;

public interface Printer {
    void print(String text);
}