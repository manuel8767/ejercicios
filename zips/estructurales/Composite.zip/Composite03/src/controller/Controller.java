package controller;

import model.Composite;
import model.Music;
import model.Song;
import view.VistaConsola;

public class Controller { 

    private VistaConsola vista;
    private Composite composite;
    private Music music;
    private String name;

    public Controller() {
        vista=new VistaConsola();
        composite=new Composite();
    }

    public void run() {

        byte option;

        do {

        option=Byte.parseByte(vista.leerTexto("\nPor favor dijita la opción que quieras realizar: \n1. Agregar canción a la playlist\n2. Eliminar canción de la playlist"+"\n3. Mostrar playlist"+"\n4. Salir\n\n"));

        switch (option) {
            case 1-> {
                addSong();
                break;
                }
            case 2-> {
                deleteSong();
                break;
                }
            case 3-> {
                vista.mostrarInformacion("\n"+info());
                break;
                }
            case 4-> {
                vista.mostrarInformacion("\nGracias por tu visita.");
                break;
                }
            }
        } while (option!=4);
        System.exit(0);

    }

    public void addSong() {
        name=vista.leerTexto("\n¿Cuál es el nombre de la canción? ");
        music=new Song(name);
        composite.adding(music);
    }

    public void deleteSong() {
        name=vista.leerTexto("\n¿Cuál es el nombre de la canción? ");
        if (composite.getName().contains(name)) {
            composite.delete(music);
        }
    }

    public String info() {
        return "Playlist\n"+composite.getName();
    }

}
