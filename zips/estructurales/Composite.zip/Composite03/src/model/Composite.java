package model;

import java.util.ArrayList;

public class Composite implements Music {

    private ArrayList<Music> playlist=new ArrayList<>();

    @Override
    public void adding(Music music) {
        playlist.add(music);
    }

    @Override
    public void delete(Music music) {
        playlist.remove(music);
    }

    @Override
    public String getName() {

        String aux="";

        for (Music i: playlist) {
            aux+=i.getName()+"\n";
        }
        return aux;
    }

}
