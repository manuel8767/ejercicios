package model;

public class Song implements Music {

    private String name;

    public Song(String name) {
        this.name=name;
    }

    @Override
    public void adding(Music music) {}

    @Override
    public void delete(Music music) {}

    @Override
    public String getName() {
        return name;
    }

}
