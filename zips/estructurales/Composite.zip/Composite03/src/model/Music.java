package model;

public interface Music {

    String getName();
    void adding(Music music);
    void delete(Music music);
}
