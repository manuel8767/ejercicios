package controller;

import model.Compuestos.Compuesta;
import model.Hojas.Chasis;
import model.Hojas.FuentePoder;
import model.Hojas.Memoria;
import model.Hojas.Mouse;
import model.Hojas.Pantalla;
import model.Hojas.Parlantes;
import model.Hojas.PlacaMadre;
import model.Hojas.Procesador;
import model.Hojas.RAM;
import model.Hojas.TarjetaGrafica;
import model.Hojas.Teclado;
import model.Interfaces.Componente;
import view.VistaConsola;

public class Controller { 

    private VistaConsola vista;
    private Compuesta pc;
    private Componente component;
    private Componente chasis;
    private Componente fuente;
    private Componente memoria;
    private Componente mouse;
    private Componente pantalla;
    private Componente parlantes;
    private Componente placa;
    private Componente procesador;
    private Componente ram;
    private Componente tarjeta;
    private Componente teclado;

    public Controller() {
        vista=new VistaConsola();
        pc=new Compuesta();
    }

    public void run() {

        byte option;

        do {

        option=Byte.parseByte(vista.leerTexto("\nPor favor dijita la opción que quieras realizar: \n1. Crear nuevo PC\n2. Eliminar partes del PC\n3. Calcular el precio del PC"+
        "\n4. Salir\n\n"));

        switch (option) {
            case 1-> {
                crearPC();
                break;
                }
            case 2-> {
                eliminarPartes();
                break;
            }
            case 3-> {
                vista.mostrarInformacion("\nEl precio de tu PC son ");
                vista.mostrarValor(calcularPrecio());
                vista.mostrarInformacion(" pesos.\n");
                break;
                }
            case 4-> {
                vista.mostrarInformacion("\nGracias por tu visita.");
                break;
                }
            }
        } while (option!=4);
        System.exit(0);

    }

    public void crearPC() {

        byte part;

        do {

        part=Byte.parseByte(vista.leerTexto("\nPor favor dijita la parte que quieras agregar a tu PC: \n1. Chasis\n2. Fuente de Poder\n3. Placa Madre\n4. Procesador\n5. SSD\n6. RAM\n7. Tarjeta Gráfica"+
        "\n8. Pantalla\n9. Teclado\n10. Mouse\n11. Parlantes\n12. Salir\n\n"));

        switch (part) {
            case 1-> {
                chasis();
                break;
                }
            case 2-> {
                fuentePoder();
                break;
                }
            case 3-> {
                placaMadre();
                break;
                }
            case 4-> {
                procesador();
                break;
                }
            case 5-> {
                memoria();
                break;
                }
            case 6-> {
                ram();
                break;
                }
            case 7-> {
                tarjetaGrafica();
                break;
                }
            case 8-> {
                pantalla();
                break;
                }
            case 9-> {
                teclado();
                break;
                }
            case 10-> {
                mouse();
                break;
                }
            case 11-> {
                parlantes();
                break;
                }
            case 12-> {
                run();
                break;
                }
            }
        } while (part!=12);
        System.exit(0);

    }

    public Componente chasis() {

        byte type;
        component=new Chasis(null, 0);

        do {

        type=Byte.parseByte(vista.leerTexto("\nPor favor dijita el tipo de chasis que quieres: \n1. Básico\n2. Estándar\n3. Pro\n4. Salir\n\n"));

        switch (type) {
            case 1-> {
                component=new Chasis("Basic", 250);
                chasis=component;
                pc.añadir(component);
                crearPC();
                break;
                }
            case 2-> {
                component=new Chasis("Standard", 500);
                chasis=component;
                pc.añadir(component);
                crearPC();
                break;
                }
            case 3-> {
                component=new Chasis("Pro", 750);
                chasis=component;
                pc.añadir(component);
                crearPC();
                break;
                }
            case 4-> {
                crearPC();
                break;
                }
            }
        } while (type!=4);
        System.exit(0);
        return component;

    }

    public Componente fuentePoder() {

        byte type;
        component=new FuentePoder(null, 0);

        do {

        type=Byte.parseByte(vista.leerTexto("\nPor favor dijita el tipo de fuente de poder que quieres: \n1. 80 Plus Silver\n2. 80 Plus Gold\n3. 80 Plus Titanium\n4. Salir\n\n"));

        switch (type) {
            case 1-> {
                component=new FuentePoder("80 Plus Silver", 500);
                fuente=component;
                pc.añadir(component);
                crearPC();
                break;
                }
            case 2-> {
                component=new FuentePoder("80 Plus Gold", 800);
                fuente=component;
                pc.añadir(component);
                break;
                }
            case 3-> {
                component=new FuentePoder("80 Plus Titanium", 1100);
                fuente=component;
                pc.añadir(component);
                break;
                }
            case 4-> {
                crearPC();
                break;
                }
            }
        } while (type!=4);
        System.exit(0);
        return component;

    }

    public Componente placaMadre() {

        byte type;
        component=new PlacaMadre(null, 0);

        do {

        type=Byte.parseByte(vista.leerTexto("\nPor favor dijita el tipo de placa madre que quieres: \n1. Básica\n2. Estándar\n3. Pro\n4. Salir\n\n"));

        switch (type) {
            case 1-> {
                component=new PlacaMadre("Basic", 400);
                placa=component;
                pc.añadir(component);
                crearPC();
                break;
                }
            case 2-> {
                component=new PlacaMadre("Standard", 600);
                placa=component;
                pc.añadir(component);
                break;
                }
            case 3-> {
                component=new PlacaMadre("Pro", 800);
                placa=component;
                pc.añadir(component);
                break;
                }
            case 4-> {
                crearPC();
                break;
                }
            }
        } while (type!=4);
        System.exit(0);
        return component;

    }

    public Componente procesador() {

        byte type;
        component=new Procesador(null, 0);

        do {

        type=Byte.parseByte(vista.leerTexto("\nPor favor dijita el tipo de procesador que quieres: \n1. Básico\n2. Estándar\n3. Pro\n4. Salir\n\n"));

        switch (type) {
            case 1-> {
                component=new Procesador("Basic", 1500);
                procesador=component;
                pc.añadir(component);
                crearPC();
                break;
                }
            case 2-> {
                component=new Procesador("Standard", 2000);
                procesador=component;
                pc.añadir(component);
                break;
                }
            case 3-> {
                component=new Procesador("Pro", 2500);
                procesador=component;
                pc.añadir(component);
                break;
                }
            case 4-> {
                crearPC();
                break;
                }
            }
        } while (type!=4);
        System.exit(0);
        return component;

    }

    public Componente memoria() {

        byte type;
        component=new Memoria(null, 0);

        do {

        type=Byte.parseByte(vista.leerTexto("\nPor favor dijita el tipo de memoria que quieres: \n1. 250 GB\n2. 500 GB\n3. 1 TB\n4. Salir\n\n"));

        switch (type) {
            case 1-> {
                component=new Memoria("250 GB", 150);
                memoria=component;
                pc.añadir(component);
                crearPC();
                break;
                }
            case 2-> {
                component=new Memoria("500 GB", 300);
                memoria=component;
                pc.añadir(component);
                break;
                }
            case 3-> {
                component=new Memoria("1 TB", 450);
                memoria=component;
                pc.añadir(component);
                break;
                }
            case 4-> {
                crearPC();
                break;
                }
            }
        } while (type!=4);
        System.exit(0);
        return component;

    }

    public Componente ram() {

        byte type;
        component=new RAM(null, 0);

        do {

        type=Byte.parseByte(vista.leerTexto("\nPor favor dijita la cantidad de RAM que quieres: \n1. 16 GB \n2. 32 GB\n3. 64 GB\n4. Salir\n\n"));

        switch (type) {
            case 1-> {
                component=new RAM("16 GB", 300);
                ram=component;
                pc.añadir(component);
                crearPC();
                break;
                }
            case 2-> {
                component=new RAM("32 GB", 600);
                ram=component;
                pc.añadir(component);
                break;
                }
            case 3-> {
                component=new RAM("64 GB", 900);
                ram=component;
                pc.añadir(component);
                break;
                }
            case 4-> {
                crearPC();
                break;
                }
            }
        } while (type!=4);
        System.exit(0);
        return component;

    }

    public Componente tarjetaGrafica() {

        byte type;
        component=new TarjetaGrafica(null, 0);

        do {

        type=Byte.parseByte(vista.leerTexto("\nPor favor dijita el tipo de tarjeta gráfica que quieres: \n1. Básica\n2. Estándar\n3. Pro\n4. Salir\n\n"));

        switch (type) {
            case 1-> {
                component=new TarjetaGrafica("Basic", 1700);
                tarjeta=component;
                pc.añadir(component);
                crearPC();
                break;
                }
            case 2-> {
                component=new TarjetaGrafica("Standard", 3400);
                tarjeta=component;
                pc.añadir(component);
                break;
                }
            case 3-> {
                component=new TarjetaGrafica("Pro", 5100);
                tarjeta=component;
                pc.añadir(component);
                break;
                }
            case 4-> {
                crearPC();
                break;
                }
            }
        } while (type!=4);
        System.exit(0);
        return component;

    }

    public Componente pantalla() {

        byte type;
        component=new Pantalla(null, 0);

        do {

        type=Byte.parseByte(vista.leerTexto("\nPor favor dijita el tipo de pantalla que quieres: \n1. 60 Hz\n2. 120 Hz\n3. 240 Hz\n4. Salir\n\n"));

        switch (type) {
            case 1-> {
                component=new Pantalla("60 Hz", 350);
                pantalla=component;
                pc.añadir(component);
                crearPC();
                break;
                }
            case 2-> {
                component=new Pantalla("120 Hz", 700);
                pantalla=component;
                pc.añadir(component);
                break;
                }
            case 3-> {
                component=new Pantalla("240 Hz", 950);
                pantalla=component;
                pc.añadir(component);
                break;
                }
            case 4-> {
                crearPC();
                break;
                }
            }
        } while (type!=4);
        System.exit(0);
        return component;

    }

    public Componente teclado() {

        byte type;
        component=new Teclado(null, 0);

        do {

        type=Byte.parseByte(vista.leerTexto("\nPor favor dijita el tipo de teclado que quieres: \n1. Básico\n2. Estándar\n3. Pro\n4. Salir\n\n"));

        switch (type) {
            case 1-> {
                component=new Teclado("Basic", 50);
                teclado=component;
                pc.añadir(component);
                crearPC();
                break;
                }
            case 2-> {
                component=new Teclado("Standard", 100);
                teclado=component;
                pc.añadir(component);
                break;
                }
            case 3-> {
                component=new Teclado("Pro", 200);
                teclado=component;
                pc.añadir(component);
                break;
                }
            case 4-> {
                crearPC();
                break;
                }
            }
        } while (type!=4);
        System.exit(0);
        return component;

    }

    public Componente mouse() {

        byte type;
        component=new Mouse(null, 0);

        do {

        type=Byte.parseByte(vista.leerTexto("\nPor favor dijita el tipo de mouse que quieres: \n1. Básico\n2. Estándar\n3. Pro\n4. Salir\n\n"));

        switch (type) {
            case 1-> {
                component=new Mouse("Basic", 25);
                mouse=component;
                pc.añadir(component);
                crearPC();
                break;
                }
            case 2-> {
                component=new Mouse("Standard", 50);
                mouse=component;
                pc.añadir(component);
                break;
                }
            case 3-> {
                component=new Mouse("Pro", 100);
                mouse=component;
                pc.añadir(component);
                break;
                }
            case 4-> {
                crearPC();
                break;
                }
            }
        } while (type!=4);
        System.exit(0);
        return component;

    }

    public Componente parlantes() {

        byte type;
        component=new Parlantes(null, 0);

        do {

        type=Byte.parseByte(vista.leerTexto("\nPor favor dijita el tipo de parlantes que quieres: \n1. Básicos\n2. Estándares\n3. Pros\n4. Salir\n\n"));

        switch (type) {
            case 1-> {
                component=new Parlantes("Basic", 75);
                parlantes=component;
                pc.añadir(component);
                crearPC();
                break;
                }
            case 2-> {
                component=new Parlantes("Standard", 150);
                parlantes=component;
                pc.añadir(component);
                break;
                }
            case 3-> {
                component=new Parlantes("Pro", 300);
                parlantes=component;
                pc.añadir(component);
                break;
                }
            case 4-> {
                crearPC();
                break;
                }
            }
        } while (type!=4);
        System.exit(0);
        return component;

    }

    public void eliminarPartes() {

        byte part;
        Componente aux;

        do {

        part=Byte.parseByte(vista.leerTexto("\nPor favor dijita la parte que quieras eliminar a tu PC: \n1. Chasis\n2. Fuente de Poder\n3. Placa Madre\n4. Procesador\n5. SSD\n6. RAM\n7. Tarjeta Gráfica"+
        "\n8. Pantalla\n9. Teclado\n10. Mouse\n11. Parlantes\n12. Salir\n\n"));

        switch (part) {
            case 1-> {
                pc.borrar(chasis);
                break;
                }
            case 2-> {
                pc.borrar(fuente);
                break;
                }
            case 3-> {
                pc.borrar(placa);
                break;
                }
            case 4-> {
                pc.borrar(procesador);
                break;
                }
            case 5-> {
                pc.borrar(memoria);
                break;
                }
            case 6-> {
                pc.borrar(ram);
                break;
                }
            case 7-> {
                pc.borrar(tarjeta);
                break;
                }
            case 8-> {
                pc.borrar(pantalla);
                break;
                }
            case 9-> {
                pc.borrar(teclado);
                break;
                }
            case 10-> {
                pc.borrar(mouse);
                break;
                }
            case 11-> {
                pc.borrar(parlantes);
                break;
                }
            case 12-> {
                run();
                break;
                }
            }
        } while (part!=12);
        System.exit(0);

    }

    public float calcularPrecio() {
        float total;
        total=pc.getprecioN();
        return total;
    }

}
