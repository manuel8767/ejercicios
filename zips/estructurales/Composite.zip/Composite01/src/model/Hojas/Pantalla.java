package model.Hojas;

import model.Interfaces.Componente;

public class Pantalla implements Componente{

    private String nombre;
    private float precioneto;

    public Pantalla(String nombre, float precio){
        this.nombre=nombre;
        this.precioneto=precio;
    }

    @Override
    public String getnombre(){
        return nombre;
    }

    @Override
    public float getprecioN(){
        return precioneto;
    }

    @Override
    public void añadir(Componente con){}

    @Override
    public void borrar(Componente con){}

}
