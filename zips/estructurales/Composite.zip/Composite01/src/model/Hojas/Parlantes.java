package model.Hojas;

import model.Interfaces.Componente;

public class Parlantes implements Componente{

    private String nombre;
    private float precioneto;

    public Parlantes(String nombre, float precio){
        this.nombre=nombre;
        this.precioneto=precio;
    }

    @Override
    public String getnombre(){
        return nombre;
    }

    @Override
    public float getprecioN(){
        return precioneto;
    }

    @Override
    public void añadir(Componente con){}

    @Override
    public void borrar(Componente con){}

}
