package model.Compuestos;

import java.util.ArrayList;
import model.Interfaces.Componente;

public class Compuesta implements Componente {

	private String nombre;
	private ArrayList<Componente> lista = new ArrayList<>();

	@Override
	public String getnombre() {
		return nombre;
	}

	@Override
	public float getprecioN() {
		float total = 0;
		for (Componente componente : lista) {
			total += componente.getprecioN();
		}
		return total;
	}

	@Override
	public void añadir(Componente con) {
		lista.add(con);
	}

	@Override
	public void borrar(Componente con) {
		lista.remove(con);
	}

}
