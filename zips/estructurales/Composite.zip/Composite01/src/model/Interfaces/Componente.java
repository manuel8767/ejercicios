package model.Interfaces;

public interface Componente {

    String getnombre();
    float getprecioN();
    void añadir(Componente con);
    void borrar(Componente con);

}
