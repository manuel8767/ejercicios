package controller;

import model.Composite;
import model.Employee;
import model.Person;
import view.VistaConsola;

public class Controller { 

    private VistaConsola vista;
    private Person person;
    private Composite composite;
    private String name;

    public Controller() {
        vista=new VistaConsola();
        composite=new Composite();
    }

    public void run() {

        byte option;

        do {

        option=Byte.parseByte(vista.leerTexto("\nPor favor dijita la opción que quieras realizar: \n1. Agregar empleado\n2. Eliminar empleado"+"\n3. Mostrar todos los empleados"+"\n4. Salir\n\n"));

        switch (option) {
            case 1-> {
                addEmployee();
                break;
                }
            case 2-> {
                deleteEmployee();
                break;
                }
            case 3-> {
                vista.mostrarInformacion("\n"+info());
                break;
                }
            case 4-> {
                vista.mostrarInformacion("\nGracias por tu visita.");
                break;
                }
            }
        } while (option!=4);
        System.exit(0);

    }

    public void addEmployee() {
        name=vista.leerTexto("\n¿Cuál es tu nombre? ");
        person=new Employee(name);
        composite.adding(person);
    }

    public void deleteEmployee() {
        name=vista.leerTexto("\n¿Cuál es tu nombre? ");
        if (composite.getName().contains(name)) {
            composite.delete(person);
        }
    }

    public String info() {
        return "Empleados\n"+composite.getName();
    }

}
