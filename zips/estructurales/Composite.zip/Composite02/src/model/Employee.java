package model;

public class Employee implements Person {

    private String name;

    public Employee(String name) {
        this.name=name;
    }

    @Override
    public void adding(Person per) {}

    @Override
    public void delete(Person per) {}

    @Override
    public String getName() {
        return name;
    }

}
