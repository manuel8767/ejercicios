package model;

import java.util.ArrayList;

public class Composite implements Person {

    private ArrayList<Person> list=new ArrayList<>();

    @Override
    public void adding(Person per) {
        list.add(per);
    }

    @Override
    public void delete(Person per) {
        list.remove(per);
    }

    @Override
    public String getName() {

        String aux="";

        for (Person i: list) {
            aux+=i.getName()+"\n";
        }
        return aux;
    }

}
