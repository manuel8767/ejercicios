package model;

public interface Person {

    String getName();
    void adding(Person per);
    void delete(Person per);

}
