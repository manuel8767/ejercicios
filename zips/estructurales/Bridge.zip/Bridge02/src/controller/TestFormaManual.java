package controller;

import model.Circulo;
import model.Forma;
import model.Renderizador;
import model.RenderizadorVectorial;
import view.FormaView;

public class TestFormaManual {
    public static void main(String[] args) {
        Renderizador render = new RenderizadorVectorial();
        Forma forma = new Circulo(render, 10f);
        FormaController controller = new FormaController(forma);
        FormaView view = new FormaView();

        controller.dibujar();
        view.mostrar("Círculo renderizado con vectorial");
    }
}