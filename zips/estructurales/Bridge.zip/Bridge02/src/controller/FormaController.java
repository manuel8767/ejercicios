package controller;

import model.Forma;

public class FormaController {
    private Forma forma;

    public FormaController(Forma forma) {
        this.forma = forma;
    }

    public void dibujar() {
        forma.dibujar();
    }
}