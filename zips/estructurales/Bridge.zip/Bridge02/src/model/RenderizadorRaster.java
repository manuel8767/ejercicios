package model;

public class RenderizadorRaster implements Renderizador {
    public void renderizarCirculo(float radio) {
        System.out.println("Dibujando círculo rasterizado de radio " + radio);
    }
}