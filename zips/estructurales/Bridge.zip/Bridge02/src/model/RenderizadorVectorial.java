package model;

public class RenderizadorVectorial implements Renderizador {
    public void renderizarCirculo(float radio) {
        System.out.println("Dibujando círculo vectorial de radio " + radio);
    }
}