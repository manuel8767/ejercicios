package model;

public class Circulo extends Forma {
    private float radio;

    public Circulo(Renderizador r, float radio) {
        super(r);
        this.radio = radio;
    }

    public void dibujar() {
        renderizador.renderizarCirculo(radio);
    }
}