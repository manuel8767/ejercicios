package model;

public interface Renderizador {
    void renderizarCirculo(float radio);
}