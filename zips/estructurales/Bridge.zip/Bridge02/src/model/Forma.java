package model;

public abstract class Forma {
    protected Renderizador renderizador;

    public Forma(Renderizador r) {
        this.renderizador = r;
    }

    public abstract void dibujar();
}