package view;


public class FormaView {
    public void mostrar(String mensaje) {
        System.out.println("Vista: " + mensaje);
    }
}