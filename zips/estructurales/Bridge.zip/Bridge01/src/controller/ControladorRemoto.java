package controller;

import model.ControlRemoto;

public class ControladorRemoto {
    private ControlRemoto control;

    public ControladorRemoto(ControlRemoto control) {
        this.control = control;
    }

    public void encender() {
        control.presionarBotonEncender();
    }

    public void apagar() {
        control.presionarBotonApagar();
    }
}