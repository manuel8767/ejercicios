package controller;

import model.ControlBasico;
import model.ControlRemoto;
import model.Dispositivo;
import model.TV;
import view.DispositivoView;

public class TestDispositivoManual {
    public static void main(String[] args) {
        Dispositivo tv = new TV();
        ControlRemoto control = new ControlBasico(tv);
        ControladorRemoto controller = new ControladorRemoto(control);
        DispositivoView view = new DispositivoView();

        controller.encender();
        view.mostrarEstado("TV encendida");

        controller.apagar();
        view.mostrarEstado("TV apagada");
    }
}