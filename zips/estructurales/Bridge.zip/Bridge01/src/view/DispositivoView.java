package view;

public class DispositivoView {
    public void mostrarEstado(String mensaje) {
        System.out.println("Estado: " + mensaje);
    }
}