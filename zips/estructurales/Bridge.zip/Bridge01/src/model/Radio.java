package model;

public class Radio implements Dispositivo {
    public void encender() {
        System.out.println("Radio encendida.");
    }

    public void apagar() {
        System.out.println("Radio apagada.");
    }
}