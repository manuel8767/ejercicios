package model;


public abstract class ControlRemoto {
    protected Dispositivo dispositivo;

    public ControlRemoto(Dispositivo dispositivo) {
        this.dispositivo = dispositivo;
    }

    public abstract void presionarBotonEncender();
    public abstract void presionarBotonApagar();
}