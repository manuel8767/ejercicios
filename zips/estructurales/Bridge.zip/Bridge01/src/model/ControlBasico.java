package model;

public class ControlBasico extends ControlRemoto {

    public ControlBasico(Dispositivo dispositivo) {
        super(dispositivo);
    }

    public void presionarBotonEncender() {
        dispositivo.encender();
    }

    public void presionarBotonApagar() {
        dispositivo.apagar();
    }
}