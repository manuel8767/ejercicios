package controller;

import model.Alerta;
import model.CanalNotificacion;
import model.Notificacion;
import model.SMS;
import view.NotificacionView;

public class TestNotificacionManual {
    public static void main(String[] args) {
        CanalNotificacion canal = new SMS();
        Notificacion notif = new Alerta(canal);
        NotificacionController controller = new NotificacionController(notif);
        NotificacionView view = new NotificacionView();

        controller.enviar("Fallo en el sistema");
        view.mostrar("Se envió alerta por SMS");
    }
}