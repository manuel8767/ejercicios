package controller;

import model.Notificacion;

public class NotificacionController {
    private Notificacion notificacion;

    public NotificacionController(Notificacion n) {
        this.notificacion = n;
    }

    public void enviar(String mensaje) {
        notificacion.enviarMensaje(mensaje);
    }
}