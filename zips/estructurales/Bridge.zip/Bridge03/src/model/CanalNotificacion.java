package model;

public interface CanalNotificacion {
    void enviar(String mensaje);
}