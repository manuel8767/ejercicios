package model;

public class Alerta extends Notificacion {
    public Alerta(CanalNotificacion canal) {
        super(canal);
    }

    public void enviarMensaje(String mensaje) {
        canal.enviar("ALERTA: " + mensaje);
    }
}