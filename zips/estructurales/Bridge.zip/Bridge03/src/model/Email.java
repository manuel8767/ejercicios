package model;

public class Email implements CanalNotificacion {
    public void enviar(String mensaje) {
        System.out.println("Enviando email: " + mensaje);
    }
}