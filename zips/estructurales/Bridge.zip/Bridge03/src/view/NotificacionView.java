package view;


public class NotificacionView {
    public void mostrar(String mensaje) {
        System.out.println("Vista de notificación: " + mensaje);
    }
}