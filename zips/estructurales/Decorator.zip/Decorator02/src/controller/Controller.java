package controller;

import model.Chain;
import model.Component;
import model.ComponentFactory;
import model.Decorator;
import model.OutfitFactory;
import model.Ring;
import view.VistaConsola;

public class Controller {

    private VistaConsola vista=new VistaConsola();
    private Component component;

    public void run() {

        ComponentFactory fabric;
        byte option;

        do { 

            option=Byte.parseByte(vista.leerTexto("\nDijita la opción que desees:\n1. Decorar outfit\n2. Salir\n\n"));

            switch (option) {
                case 1-> {
                    fabric=new OutfitFactory();
                    component=fabric.create();
                    decorations();
                    break;
                }
                case 2-> {
                    break;
                }
            }
        } while (option!=2);
        System.exit(0);

    }

    public void decorations() {

        byte select;
        Decorator decorator=null;
        String temp="", temp2="";

        do { 

            select=Byte.parseByte(vista.leerTexto("\nDijita la opción que desees:\n1. Agregar cadena\n2. Agregar anillos\n3. Ver cambios\n4. Salir\n\n"));

            switch (select) {
                case 1-> {
                    decorator=new Chain(component);
                    temp=decorator.show();
                    break;
                }
                case 2-> {
                    decorator=new Ring(component);
                    temp2=decorator.show();
                    break;
                }
                case 3-> {
                    vista.mostrarInformacion(component.show()+temp+temp2);
                    break;
                }
                case 4-> {
                    run();
                    break;
                }
            } 
        } while (select!=4);
        System.exit(0);

    }

}
