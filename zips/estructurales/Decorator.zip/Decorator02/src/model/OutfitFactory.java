package model;

public class OutfitFactory extends ComponentFactory {

    @Override
    public Component create() {
        return new Outfit();
    }

}
