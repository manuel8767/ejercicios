package model;

public class Outfit extends Component {

    @Override
    public String show() {
        return "\nOutfit:";
    }

}
