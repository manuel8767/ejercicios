package model;

public class Ring extends Decorator {

    public Ring(Component component) {
        super(component);
    }

    @Override
    public String show() {
        return "\ncon anillos.";
    }

}
