package model;

public class Chain extends Decorator {

    public Chain(Component component) {
        super(component);
    }

    @Override
    public String show() {
        return "\ncon cadena.";
    }

}
