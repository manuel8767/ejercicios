package controller;

import model.CakeFactory;
import model.Chispitas;
import model.Component;
import model.ComponentFactory;
import model.Decorator;
import model.Fresas;
import model.Helado;
import view.VistaConsola;

public class Controller {

    private VistaConsola vista=new VistaConsola();
    private Component component;

    public void run() {

        ComponentFactory fabric;
        byte option;

        do { 

            option=Byte.parseByte(vista.leerTexto("\nDijita la opción que desees:\n1. Decorar pastel\n2. Salir\n\n"));

            switch (option) {
                case 1-> {
                    fabric=new CakeFactory();
                    component=fabric.create();
                    decorations();
                    break;
                }
                case 2-> {
                    break;
                }
            }
        } while (option!=2);
        System.exit(0);

    }

    public void decorations() {

        byte select;
        Decorator decorator=null;
        String temp="", temp2="", temp3="";

        do { 

            select=Byte.parseByte(vista.leerTexto("\nDijita la opción que desees:\n1. Agregar fresas\n2. Agregar chispitas\n3. Agregar helado\n4. Ver cambios\n5. Salir\n\n"));

            switch (select) {
                case 1-> {
                    decorator=new Fresas(component);
                    temp=decorator.show();
                    break;
                }
                case 2-> {
                    decorator=new Chispitas(component);
                    temp2=decorator.show();
                    break;
                }
                case 3-> {
                    decorator=new Helado(component);
                    temp3=decorator.show();
                    break;
                }
                case 4-> {
                    vista.mostrarInformacion(component.show()+temp+temp2+temp3);
                    break;
                }
                case 5-> {
                    run();
                    break;
                }
            } 
        } while (select!=5);
        System.exit(0);

    }

}
