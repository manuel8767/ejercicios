package model;

public class Fresas extends Decorator {

    public Fresas(Component component) {
        super(component);
    }

    @Override
    public String show() {
        return "\ncon fresas.";
    }

}
