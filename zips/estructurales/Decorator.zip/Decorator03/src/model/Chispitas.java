package model;

public class Chispitas extends Decorator {

    public Chispitas(Component component) {
        super(component);
    }

    @Override
    public String show() {
        return "\ncon chispitas.";
    }

}
