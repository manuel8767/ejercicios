package model;

public class Cake extends Component {

    @Override
    public String show() {
        return "\nPastel:";
    }

}
