package model;

public class CakeFactory extends ComponentFactory {

    @Override
    public Component create() {
        return new Cake();
    }

}
