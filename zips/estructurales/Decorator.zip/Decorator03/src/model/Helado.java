package model;

public class Helado extends Decorator {

    public Helado(Component component) {
        super(component);
    }

    @Override
    public String show() {
        return "\ncon helado.";
    }

}
