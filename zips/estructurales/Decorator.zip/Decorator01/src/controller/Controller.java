package controller;

import model.BedRoomFactory;
import model.Clock;
import model.Component;
import model.ComponentFactory;
import model.Decorator;
import model.LivingRoomFactory;
import model.Poster;
import view.VistaConsola;

public class Controller {

    private VistaConsola vista=new VistaConsola();
    private Component component;

    public void run() {

        ComponentFactory fabric;
        byte option;

        do { 

            option=Byte.parseByte(vista.leerTexto("\nDijita la opción que desees:\n1. Decorar dormitorio\n2. Decorar sala\n3. Salir\n\n"));

            switch (option) {
                case 1-> {
                    fabric=new BedRoomFactory();
                    component=fabric.option();
                    decorations();
                    break;
                }
                case 2-> {
                    fabric=new LivingRoomFactory();
                    component=fabric.option();
                    decorations();
                    break;
                }
                case 3-> {
                    break;
                }
            }
        } while (option!=3);
        System.exit(0);

    }

    public void decorations() {

        byte select;
        Decorator decorator=null;
        String temp="", temp2="";

        do { 

            select=Byte.parseByte(vista.leerTexto("\nDijita la opción que desees:\n1. Agregar posters\n2. Agregar relog\n3. Ver cambios\n4. Salir\n\n"));

            switch (select) {
                case 1-> {
                    decorator=new Poster(component);
                    temp=decorator.show();
                    break;
                }
                case 2-> {
                    decorator=new Clock(component);
                    temp2=decorator.show();
                    break;
                }
                case 3-> {
                    vista.mostrarInformacion(component.show()+temp+temp2);
                    break;
                }
                case 4-> {
                    run();
                    break;
                }
            } 
        } while (select!=4);
        System.exit(0);

    }

}
