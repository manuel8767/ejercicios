package model;

public abstract class Component {

    public abstract String show();

}
