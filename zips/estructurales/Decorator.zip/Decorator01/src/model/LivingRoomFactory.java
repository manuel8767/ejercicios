package model;

public class LivingRoomFactory extends ComponentFactory {

    @Override
    public Component option() {
        return new LivingRoom();
    }

}
