package model;

public class Poster extends Decorator {

    public Poster(Component component) {
        super(component);
    }

    @Override
    public String show() {
        return "\ncon pósters.";
    }

}
