package model;

public class BedRoomFactory extends ComponentFactory {

    @Override
    public Component option() {
        return new BedRoom();
    }

}
