package model;

public class BedRoom extends Component {

    @Override
    public String show() {
        return "\nDormitorio:";
    }

}
