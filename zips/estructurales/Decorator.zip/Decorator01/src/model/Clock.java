package model;

public class Clock extends Decorator {

    public Clock(Component component) {
        super(component);
    }

    @Override
    public String show() {
        return "\ncon reloj.";
    }

}
