package model;

public class LivingRoom extends Component {

    @Override
    public String show() {
        return "\nSala:";
    }

}
