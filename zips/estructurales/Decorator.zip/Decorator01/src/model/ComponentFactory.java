package model;

public abstract class ComponentFactory {

    public abstract Component option();

}
