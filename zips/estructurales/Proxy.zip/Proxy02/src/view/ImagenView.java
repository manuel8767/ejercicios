package view;


public class ImagenView {
    public void mostrarMensaje(String mensaje) {
        System.out.println("Vista: " + mensaje);
    }
}