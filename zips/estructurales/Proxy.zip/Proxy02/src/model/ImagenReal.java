package model;


public class ImagenReal implements Imagen {
    private String archivo;

    public ImagenReal(String archivo) {
        this.archivo = archivo;
        cargarDesdeDisco(archivo);
    }

    private void cargarDesdeDisco(String archivo) {
        System.out.println("Cargando imagen desde disco: " + archivo);
    }

    public void mostrar() {
        System.out.println("Mostrando imagen: " + archivo);
    }
}