package model;

public interface Imagen {
    void mostrar();
}