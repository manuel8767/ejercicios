package controller;

import model.Imagen;

public class ImagenController {
    private Imagen imagen;

    public ImagenController(Imagen imagen) {
        this.imagen = imagen;
    }

    public void verImagen() {
        imagen.mostrar();
    }
}