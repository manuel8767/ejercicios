package controller;

import model.Imagen;
import model.ImagenProxy;
import view.ImagenView;

public class TestImagenManual {
    public static void main(String[] args) {
        ImagenView vista = new ImagenView();
        Imagen imagen = new ImagenProxy("paisaje.jpg");
        ImagenController controller = new ImagenController(imagen);

        vista.mostrarMensaje("Primera visualización:");
        controller.verImagen(); 

        vista.mostrarMensaje("Segunda visualización:");
        controller.verImagen(); 
    }
}