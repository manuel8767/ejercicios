package view;


public class DocumentoView {
    public void mostrarMensaje(String mensaje) {
        System.out.println("Vista: " + mensaje);
    }
}
