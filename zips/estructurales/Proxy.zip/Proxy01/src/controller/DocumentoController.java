package controller;

import model.Documento;

public class DocumentoController {
    private Documento documento;

    public DocumentoController(Documento doc) {
        this.documento = doc;
    }

    public void verDocumento() {
        documento.mostrar();
    }
}