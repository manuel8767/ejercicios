package controller;

import model.Documento;
import model.DocumentoProxy;
import view.DocumentoView;

public class TestDocumentoManual {
    public static void main(String[] args) {
        DocumentoView vista = new DocumentoView();

        Documento doc1 = new DocumentoProxy("Contrato.pdf", true);
        DocumentoController controller1 = new DocumentoController(doc1);
        vista.mostrarMensaje("Intentando abrir documento con permisos...");
        controller1.verDocumento();

        Documento doc2 = new DocumentoProxy("Secretos.txt", false);
        DocumentoController controller2 = new DocumentoController(doc2);
        vista.mostrarMensaje("Intentando abrir documento sin permisos...");
        controller2.verDocumento();
    }
}