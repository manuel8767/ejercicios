package model;

public class DocumentoProxy implements Documento {
    private DocumentoReal documentoReal;
    private String nombre;
    private boolean tienePermiso;

    public DocumentoProxy(String nombre, boolean tienePermiso) {
        this.nombre = nombre;
        this.tienePermiso = tienePermiso;
    }

    public void mostrar() {
        if (!tienePermiso) {
            System.out.println("Acceso denegado al documento: " + nombre);
            return;
        }

        if (documentoReal == null) {
            documentoReal = new DocumentoReal(nombre);
        }

        documentoReal.mostrar();
    }
}