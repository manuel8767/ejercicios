package model;

public interface Documento {
    void mostrar();
}