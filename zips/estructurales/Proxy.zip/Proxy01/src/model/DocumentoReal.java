package model;

public class DocumentoReal implements Documento {
    private String nombre;

    public DocumentoReal(String nombre) {
        this.nombre = nombre;
        System.out.println("Cargando documento: " + nombre);
    }

    public void mostrar() {
        System.out.println("Mostrando documento: " + nombre);
    }
}