package controller;

import model.BaseDatos;
import model.BaseDatosProxy;
import view.BaseDatosView;

public class TestBaseDatosManual {
    public static void main(String[] args) {
        BaseDatosView vista = new BaseDatosView();

        BaseDatos db1 = new BaseDatosProxy("admin");
        BaseDatosController controller1 = new BaseDatosController(db1);
        vista.mostrar("Consulta como admin:");
        controller1.ejecutarConsulta("SELECT * FROM usuarios");

        BaseDatos db2 = new BaseDatosProxy("invitado");
        BaseDatosController controller2 = new BaseDatosController(db2);
        vista.mostrar("Consulta como invitado:");
        controller2.ejecutarConsulta("DELETE FROM datos");
    }
}