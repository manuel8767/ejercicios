package controller;

import model.BaseDatos;

public class BaseDatosController {
    private BaseDatos db;

    public BaseDatosController(BaseDatos db) {
        this.db = db;
    }

    public void ejecutarConsulta(String consulta) {
        db.consultar(consulta);
    }
}