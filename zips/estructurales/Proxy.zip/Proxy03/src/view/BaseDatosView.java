package view;

public class BaseDatosView {
    public void mostrar(String mensaje) {
        System.out.println("Vista: " + mensaje);
    }
}