package model;

public interface BaseDatos {
    void consultar(String consulta);
}