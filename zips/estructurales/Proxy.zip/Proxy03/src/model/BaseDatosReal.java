package model;

public class BaseDatosReal implements BaseDatos {
    public void consultar(String consulta) {
        System.out.println("Ejecutando consulta: " + consulta);
    }
}