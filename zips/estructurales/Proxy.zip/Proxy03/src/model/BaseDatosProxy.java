package model;

public class BaseDatosProxy implements BaseDatos {
    private BaseDatosReal real = new BaseDatosReal();
    private String usuario;

    public BaseDatosProxy(String usuario) {
        this.usuario = usuario;
    }

    public void consultar(String consulta) {
        if (!usuario.equals("admin")) {
            System.out.println("Usuario no autorizado: " + usuario);
            return;
        }
        real.consultar(consulta);
    }
}